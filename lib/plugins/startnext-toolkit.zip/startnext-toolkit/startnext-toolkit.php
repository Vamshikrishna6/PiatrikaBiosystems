<?php
/* 
 * Plugin Name: StartNext Toolkit
 * Author: EnvyTheme Team
 * Author URI: envytheme.com
 * Description: A Light weight and easy toolkit for StartNext theme
 * Version: 3.0.0
 */
if (!defined('ABSPATH')) {
    exit; //Exit if accessed directly
}

if( !defined('STARTNEXT_FRAMEWORK_VAR') ) define('STARTNEXT_FRAMEWORK_VAR', 'startnext_opt');

//define
define('STARTNEXT_ACC_URL', WP_PLUGIN_URL . '/' . plugin_basename(dirname(__FILE__)) . '/');
define('STARTNEXT_ACC_PATH', plugin_dir_path(__FILE__));

function startnext_toolkit_get_page_as_list()
{
    $args = wp_parse_args(array(
        'post_type' => 'page',
        'numberposts' => -1,
    ));

    $posts = get_posts($args);
    $post_options = array(esc_html__('--Select Page--', 'startnext-toolkit') => '');

    if ($posts) {
        foreach ($posts as $post) {
            $post_options[$post->post_title] = $post->ID;
        }
    }
    return $post_options;
}

function startnext_toolkit_get_page_feature_cat()
{
    $arg = array(
        'taxonomy' => 'feature_cat',
        'orderby' => 'name',
        'order'   => 'ASC'
    );
    $args = get_categories($arg);
    $args_options = array(esc_html__('--Select Category--', 'startnext-toolkit') => '');
    if ($args) {
        foreach ($args as $args) {
            $args_options[$args->name] = $args->term_id;
        }
    }
    return $args_options;
}

function startnext_toolkit_get_page_service_cat()
{
    $arg = array(
        'taxonomy' => 'service_cat',
        'orderby' => 'name',
        'order'   => 'ASC'
    );
    $args = get_categories($arg);
    $args_options = array(esc_html__('--Select Category--', 'startnext-toolkit') => '');
    if ($args) {
        foreach ($args as $args) {
            $args_options[$args->name] = $args->slug;
        }
    }
    return $args_options;
}

//Print short codes in widgets
add_filter('widget_text', 'do_shortcode');

//Custom Post
function startnext_toolkit_custom_post()
{
    //Project Custom Post
    register_post_type('project',
        array(
            'labels' => array(
                'name' => esc_html__('Projects', 'startnext-toolkit'),
                'singular_name' => esc_html__('Project', 'startnext-toolkit'),
            ),
            'menu_icon' => 'dashicons-images-alt',
            'supports' => array('title', 'thumbnail', 'editor', 'excerpt'),
            'public' => true,  
        )
    );
    
    //Features Custom Post
    register_post_type('feature',
        array(
            'labels' => array(
                'name' => esc_html__('Features', 'startnext-toolkit'),
                'singular_name' => esc_html__('Feature', 'startnext-toolkit'),
            ),
            'menu_icon' => 'dashicons-feedback',
            'supports' => array('title', 'editor', 'excerpt', 'thumbnail'),
            'public' => true,   
            'show_in_rest' => true,  
            'has_archive' => true,         
        )
    );

    //Services Custom Post
    register_post_type('services',
        array(
            'labels' => array(
                'name' => esc_html__('Services', 'startnext-toolkit'),
                'singular_name' => esc_html__('Service', 'startnext-toolkit'),
            ),
            'menu_icon' => 'dashicons-groups',
            'supports' => array('title', 'editor', 'excerpt'),
            'public' => true,   
            'show_in_rest' => true,  
            'has_archive' => true,         
        )
    );


}
add_action('init', 'startnext_toolkit_custom_post');

//Taxonomy Custom Post
function startnext_custom_post_taxonomy(){
    register_taxonomy(
      'project_cat',
      'project',
        array(
          'hierarchical'      => true,
          'label'             => esc_html__('Projects Category', 'startnext-toolkit' ),
          'query_var'         => true,
          'show_admin_column' => true,
              'rewrite'         => array(
              'slug'          => 'project-category',
              'with_front'    => true
              )
        )
      );
    
    register_taxonomy(
        'feature_cat',
        'feature',
            array(
            'hierarchical'      => true,
            'label'             => esc_html__('Feature Category', 'startnext-toolkit' ),
            'query_var'         => true,
            'show_admin_column' => true,
                'rewrite'         => array(
                'slug'          => 'feature-category',
                'with_front'    => true
                )
            )
    );

    register_taxonomy(
        'service_cat',
        'services',
            array(
            'hierarchical'      => true,
            'label'             => esc_html__('Service Category', 'startnext-toolkit' ),
            'query_var'         => true,
            'show_admin_column' => true,
                'rewrite'         => array(
                'slug'          => 'service-category',
                'with_front'    => true
                )
            )
    );
  }
add_action('init', 'startnext_custom_post_taxonomy');

//Shortcode depended on Visual Composer
include_once(ABSPATH . 'wp-admin/includes/plugin.php');

if (is_plugin_active('js_composer/js_composer.php')) {

    //Loading VC addons
    require_once(STARTNEXT_ACC_PATH . 'vc-addons/vc-blocks-load.php');

    //Theme Shortcode
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/section-title-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/banner-one-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/banner-two-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/hosting-banner-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/hosting-banner-slider-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/features-box-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/features-box-slider-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/hosting-service-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/design-and-development-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/our-team-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/fun-facts-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/contact-box-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/pricing-plans-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/user-feedback-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/ready-to-talk-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/partner-logo-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/our-recent-works.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/post-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/domain-search-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/why-choose-us-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/cta-area-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/our-services-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/faq-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/about-us-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/contact-info-cards-shortcode.php');
    require_once(STARTNEXT_ACC_PATH . 'theme-shortcodes/more-info-shortcode.php');
    }

//Registering crazy toolkit files
function startnext_toolkit_files()
{
    wp_enqueue_style('startnext-toolkit', plugin_dir_url(__FILE__) . 'assets/css/startnext-toolkit.css');
}

add_action('wp_enqueue_scripts', 'startnext_toolkit_files');

if ( ! function_exists( 'startnext_text_domain' ) ) {
	//Loads plugin text domain so it can be used in translation
	function startnext_text_domain() {
		load_plugin_textdomain( 'startnext-toolkit', false, STARTNEXT_ACC_PATH . '/languages' );
	}
	add_action( 'plugins_loaded', 'startnext_text_domain' );
}

add_filter('script_loader_tag', 'startnext_clean_script_tag');
  function startnext_clean_script_tag($input) {
        $input = str_replace( array( 'type="text/javascript"', "type='text/javascript'" ), '', $input );
        return $input;
}

// Redux Theme Options
require_once( STARTNEXT_ACC_PATH . 'redux/ReduxCore/framework.php');
require_once( STARTNEXT_ACC_PATH . 'redux/sample/sample-config.php');

/* Elementor Setup */
if (is_plugin_active('elementor/elementor.php')) {
    final class Elementor_StartNext_Extension {

        const VERSION = '1.0.0';
        const MINIMUM_ELEMENTOR_VERSION = '2.0.0';
        const MINIMUM_PHP_VERSION = '7.0';

        // Instance
        private static $_instance = null;
        
        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }
            return self::$_instance;

        }

        // Constructor
        public function __construct() {
            add_action( 'plugins_loaded', [ $this, 'init' ] );

        }

        // init
        public function init() {
            load_plugin_textdomain( 'startnext-toolkit' );

            // Check if Elementor installed and activated
            if ( ! did_action( 'elementor/loaded' ) ) {
                add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
                return;
            }

            // Check for required Elementor version
            if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
                add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
                return;
            }

            // Check for required PHP version
            if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
                add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
                return;
            }

            // Add Plugin actions
            add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
            
            add_action('elementor/elements/categories_registered',[ $this, 'register_new_category'] );
            
        }

        public function register_new_category($manager){
            $manager->add_category('startnext-elements',[
                'title'=>esc_html__('StartNext','startnext-toolkit'),
                'icon'=> 'fa fa-image'
            ]);
        }

        //Admin notice
        public function admin_notice_minimum_elementor_version() {

            if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

            $message = sprintf(
                /* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
                esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'startnext-toolkit' ),
                '<strong>' . esc_html__( 'StartNext', 'startnext-toolkit' ) . '</strong>',
                '<strong>' . esc_html__( 'Elementor', 'startnext-toolkit' ) . '</strong>',
                self::MINIMUM_ELEMENTOR_VERSION
            );

            printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

        }
        public function admin_notice_minimum_php_version() {

            if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

            $message = sprintf(
                /* translators: 1: Plugin name 2: PHP 3: Required PHP version */
                esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'startnext-toolkit' ),
                '<strong>' . esc_html__( 'StartNext', 'startnext-toolkit' ) . '</strong>',
                '<strong>' . esc_html__( 'PHP', 'startnext-toolkit' ) . '</strong>',
                self::MINIMUM_PHP_VERSION
            );

            printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

        }

        // Toolkit Widgets
        public function init_widgets() {

            // Include Widget files
            require_once( __DIR__ . '/el-addons/section.php' );
            require_once( __DIR__ . '/el-addons/banner-one.php' );
            require_once( __DIR__ . '/el-addons/banner-slider.php' );
            require_once( __DIR__ . '/el-addons/hosting-banner.php' );
            require_once( __DIR__ . '/el-addons/features.php' );
            require_once( __DIR__ . '/el-addons/services.php' );
            require_once( __DIR__ . '/el-addons/recent-works.php' );
            require_once( __DIR__ . '/el-addons/hosting-service.php' );
            require_once( __DIR__ . '/el-addons/team.php' );
            require_once( __DIR__ . '/el-addons/funfacts.php' );
            require_once( __DIR__ . '/el-addons/contact-box.php' );
            require_once( __DIR__ . '/el-addons/pricing.php' );
            require_once( __DIR__ . '/el-addons/testimonial.php' );
            require_once( __DIR__ . '/el-addons/partner.php' );
            require_once( __DIR__ . '/el-addons/post.php' );
            require_once( __DIR__ . '/el-addons/features-box-slider.php' );
            require_once( __DIR__ . '/el-addons/domain-search.php' );
            require_once( __DIR__ . '/el-addons/why-choose-us.php' );
            require_once( __DIR__ . '/el-addons/partner-logo.php' );
            require_once( __DIR__ . '/el-addons/about-us.php' );
            require_once( __DIR__ . '/el-addons/cta-area.php' );
            require_once( __DIR__ . '/el-addons/more-info.php' );
            require_once( __DIR__ . '/el-addons/faq.php' );
            require_once( __DIR__ . '/el-addons/contact-card.php' );
        }

    }
    Elementor_StartNext_Extension::instance();
}

function startnext_toolkit_get_page_feature_cat_el()
{
    $arg = array(
        'taxonomy' => 'feature_cat',
        'orderby' => 'name',
        'order'   => 'ASC'
    );
    $args = get_categories($arg);
    $args_options = array(esc_html__('', 'startnext-toolkit') => '');
    if ($args) {
        foreach ($args as $args) {
            $args_options[$args->name] = $args->slug;
        }
    }
    return $args_options;
}

function startnext_toolkit_get_page_services_cat_el()
{
    $arg = array(
        'taxonomy' => 'service_cat',
        'orderby' => 'name',
        'order'   => 'ASC'
    );
    $args = get_categories($arg);
    $args_options = array(esc_html__('', 'startnext-toolkit') => '');
    if ($args) {
        foreach ($args as $args) {
            $args_options[$args->name] = $args->slug;
        }
    }
    return $args_options;
}

/**
 * Extend Icon pack core controls.
 */ 
function StartNext_icon_pack( $controls_manager ) {

	require_once(STARTNEXT_ACC_PATH . 'inc/icon.php');

	$controls = array(
		$controls_manager::ICON => 'StartNext_Icon_Controler',
	);

	foreach ( $controls as $control_id => $class_name ) {
		$controls_manager->unregister_control( $control_id );
		$controls_manager->register_control( $control_id, new $class_name() );
	}

}

// This is your option name where all the Redux data is stored.
$opt_name = STARTNEXT_FRAMEWORK_VAR;

?>