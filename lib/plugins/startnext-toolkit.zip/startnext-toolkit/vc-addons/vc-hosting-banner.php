<?php
vc_map( 
    array(
        "name" => esc_html__( "Hosting Banner", 'startnext-toolkit' ),
        "base" => "startnext_banner_hosting",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Title", 'startnext-toolkit' ),
                "param_name" => "title",
            ),
            array(
                "type" => "textarea_html",
                "heading" => esc_html__( "Description", 'startnext-toolkit' ),
                "param_name" => "content",
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Side Image", 'startnext-toolkit' ),
                "param_name" => "img",
            ),

            array(
                "type" => "textfield",
                "heading" => esc_html__( "Button Name", 'startnext-toolkit' ),
                "param_name" => "btnname",
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Button Link Type", 'startnext-toolkit' ),
                "param_name" => "type",
                "std" => esc_html__( "1", 'startnext-toolkit' ),
                "value" => array(
                    'Link to page' => 1,
                    'External link' => 2,
                ),
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Page", 'startnext-toolkit' ),
                "param_name" => "link_to_page",
                "value" => startnext_toolkit_get_page_as_list(),
                'dependency' => array(
                    "element" => "type",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "External Link", 'startnext-toolkit' ),
                "param_name" => "external_link",
                'dependency' => array(
                    "element" => "type",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
        )
    )   
);