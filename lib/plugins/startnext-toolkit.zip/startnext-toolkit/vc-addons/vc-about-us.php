<?php
vc_map( 
    array(
        "name" => esc_html__( "About Us", 'startnext-toolkit' ),
        "base" => "startnext_about_us",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(
            array(
                "type"          => "dropdown",
                "heading"       => esc_html__( "Choose Style", 'startnext-toolkit' ),
                "param_name"    => "style",
                'admin_label'   => true,
                    'value'       => array(
                    'Style - 1'   => 1,
                    'Style - 2'   => 2,
                ),
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Small Title", 'startnext-toolkit' ),
                "param_name" => "sm_title",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Heading", 'startnext-toolkit' ),
                "param_name" => "title",
            ),
            array(
                "type" => "textarea_html",
                "heading" => esc_html__( "Content", 'startnext-toolkit' ),
                "param_name" => "content",
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Side Image", 'startnext-toolkit' ),
                "param_name" => "img",
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Side Image 2", 'startnext-toolkit' ),
                "param_name" => "img2",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Side Image 3", 'startnext-toolkit' ),
                "param_name" => "img3",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Side Image 4", 'startnext-toolkit' ),
                "param_name" => "img4",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Side Image 5", 'startnext-toolkit' ),
                "param_name" => "img5",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                'type' => 'param_group',
                'param_name' => 'group_about_card', 
                "heading" => esc_html__( "Add Your Card", 'startnext-toolkit' ),
                'dependency' => array(
                    "element" => "style",
                    "value" => array("1"),
                ),
                'params' => array(
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Title", 'startnext-toolkit' ),
                        "param_name" => "title",
                    ),
                    array(
                        "type" => "textarea",
                        "heading" => esc_html__( "Description", 'startnext-toolkit' ),
                        "param_name" => "description",
                    ), 
                )
            ),
            array(
                'type' => 'param_group',
                'param_name' => 'group_about_card2', 
                "heading" => esc_html__( "Add Your Item", 'startnext-toolkit' ),
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                ),
                'params' => array(
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Title", 'startnext-toolkit' ),
                        "param_name" => "title",
                    ),
                )
            ),

            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
        )
    )   
);