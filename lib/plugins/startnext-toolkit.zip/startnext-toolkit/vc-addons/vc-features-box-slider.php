<?php
vc_map( 
    array(
        "name" => esc_html__( "Features Box Slider", 'startnext-toolkit' ),
        "base" => "startnext_fatures_box_slider",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(

            array(
                'type' => 'param_group',
                'param_name' => 'group_features', 
                "heading" => esc_html__( "Add Feature Item", 'startnext-toolkit' ),
                'params' => array(
                    array(
                        "type" => "iconpicker",
                        "heading" => esc_html__( "Icon", 'startnext-toolkit' ),
                        "param_name" => "icon",
                    ),
                    array(
                        "type" => "colorpicker",
                        "heading" => esc_html__( "Icon Color", 'startnext-toolkit' ),
                        "param_name" => "iconcolor",
                        "value" => esc_html__( "#44ce6f", 'startnext-toolkit' ),
        
                    ),
                    array(
                        "type" => "colorpicker",
                        "heading" => esc_html__( "Icon Backgorund Color", 'startnext-toolkit' ),
                        "param_name" => "iconbg",
                        "value" => esc_html__( "#cdf1d8", 'startnext-toolkit' ),
        
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Title", 'startnext-toolkit' ),
                        "param_name" => "title",
                    ),
                    array(
                        "type" => "textarea",
                        "heading" => esc_html__( "Description", 'startnext-toolkit' ),
                        "param_name" => "description",
                    ), 
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
        )
    )   
);