<?php
vc_map( 
    array(
        "name" => esc_html__( "Contact Info Cards", 'startnext-toolkit' ),
        "base" => "startnext_contact_info_cards",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(

            array(
                "type" => "textfield",
                "heading" => esc_html__( "Email Title", 'startnext-toolkit' ),
                "param_name" => "emailtitle",
            ),
            array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Icon", 'startnext-toolkit' ),
                "param_name" => "emailicon",
            ),
            array(
                'type' => 'param_group',
                'param_name' => 'group_email', 
                "heading" => esc_html__( "Add Email Addresses ", 'startnext-toolkit' ),
                'params' => array(
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Put Your Address", 'startnext-toolkit' ),
                        "param_name" => "address",
                    ),
                )
            ),

            array(
                "type" => "textfield",
                "heading" => esc_html__( "Address Title", 'startnext-toolkit' ),
                "param_name" => "addresstitle",
            ),
            array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Icon", 'startnext-toolkit' ),
                "param_name" => "addressicon",
            ),
            array(
                'type' => 'param_group',
                'param_name' => 'group_address', 
                "heading" => esc_html__( "Add Addresses ", 'startnext-toolkit' ),
                'params' => array(
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Put Your Address", 'startnext-toolkit' ),
                        "param_name" => "address",
                    ),
                )
            ),

            array(
                "type" => "textfield",
                "heading" => esc_html__( "Phone Title", 'startnext-toolkit' ),
                "param_name" => "phonetitle",
            ),
            array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Icon", 'startnext-toolkit' ),
                "param_name" => "phoneicon",
            ),
            array(
                'type' => 'param_group',
                'param_name' => 'group_phone', 
                "heading" => esc_html__( "Add Phone Number ", 'startnext-toolkit' ),
                'params' => array(
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Put Your Phone Number", 'startnext-toolkit' ),
                        "param_name" => "address",
                    ),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
        )
    )   
);