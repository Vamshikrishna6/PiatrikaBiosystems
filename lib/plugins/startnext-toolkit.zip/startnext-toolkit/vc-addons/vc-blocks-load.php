<?php
if(!defined('ABSPATH')){
    die('-1');
}
//Class Started
class startpVCExtendAddonClass{
    function __construct(){
        //We safely integrate with VC with this hook
        add_action('init', array($this, 'startpIntegrateWithVC'));
    }
    public function startpIntegrateWithVC(){

        //Check if visual composer is not installed 
        if(! defined('WPB_VC_VERSION')){
            add_action('admin_notices', array($this, 'startpShowVcVersionNotice'));
            return;
        }  
        // vc Addons 
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-section-title.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-banner-one.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-banner-two.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-hosting-banner-slider.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-hosting-banner.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-features-box.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-features-box-slider.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-hosting-service.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-design-and-development.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-our-team.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-fun-facts.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-contact-box.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-pricing-plan.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-user-feedback.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-ready-to-talk.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-partner-logo.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-our-recent-works.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-post.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-our-services.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-why-choose-us.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-cta-area.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-domain-search.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-faq.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-about-us.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-contact-info-cards.php';
        include STARTNEXT_ACC_PATH . '/vc-addons/vc-more-info.php';
        
    }
}
new startpVCExtendAddonClass();