<?php
vc_map( 
    array(
        "name" => esc_html__( "Pricing Plan", 'startnext-toolkit' ),
        "base" => "startnext_pricing_plan",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Select Style", 'startnext-toolkit' ),
                "param_name" => "style",
                "std" => esc_html__( "1", 'startnext-toolkit' ),
                "value" => array(
                    __('Style One', 'startnext-toolkit') => 1,
                    __('Style Two', 'startnext-toolkit') => 2,
                ),
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Package Name", 'startnext-toolkit' ),
                "param_name" => "name",
            ),
            array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Package Icon", 'startnext-toolkit' ),
                "param_name" => "icon",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Package Price", 'startnext-toolkit' ),
                "param_name" => "price",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Package Duration", 'startnext-toolkit' ),
                "param_name" => "duration",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Currency Symbol", 'startnext-toolkit' ),
                "param_name" => "symble",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Button Name", 'startnext-toolkit' ),
                "param_name" => "btnname",
            ),

            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Button Link Type", 'startnext-toolkit' ),
                "param_name" => "type",
                "std" => esc_html__( "1", 'startnext-toolkit' ),
                "value" => array(
                    'Link to page' => 1,
                    'External link' => 2,
                ),
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Page", 'startnext-toolkit' ),
                "param_name" => "link_to_page",
                "value" => startnext_toolkit_get_page_as_list(),
                'dependency' => array(
                    "element" => "type",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "External Link", 'startnext-toolkit' ),
                "param_name" => "external_link",
                'dependency' => array(
                    "element" => "type",
                    "value" => array("2"),
                )
            ),

            array(
                'type' => 'param_group',
                'param_name' => 'group_package_features', 
                'params' => array(
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Package Feature Name", 'startnext-toolkit' ),
                        "param_name" => "feature",
                    ),
                    array(
                        "type" => "checkbox",
                        "heading" => esc_html__( "Disable this Feature?", 'startnext-toolkit' ),
                        "param_name" => "featuredisable",
                    ),
                )
            ),
            array(
                "type" => "checkbox",
                "heading" => esc_html__( "Package Active?", 'startnext-toolkit' ),
                "param_name" => "packageactive",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
        )
    )   
);