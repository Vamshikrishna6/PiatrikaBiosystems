<?php
vc_map( 
    array(
        "name" => esc_html__( "Our Team", 'startnext-toolkit' ),
        "base" => "startnext_our_team",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(
            array(
                'type' => 'param_group',
                'param_name' => 'group_teams', 
                'params' => array(
                    array(
                        "type" => "attach_image",
                        "heading" => esc_html__( "Profile Image", 'startnext-toolkit' ),
                        "param_name" => "img",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Name", 'startnext-toolkit' ),
                        "param_name" => "name",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Designation", 'startnext-toolkit' ),
                        "param_name" => "designation",
                    ),
                    array(
                        "type" => "textarea",
                        "heading" => esc_html__( "Description", 'startnext-toolkit' ),
                        "param_name" => "description",
                    ),

                    array(
                        'type' => 'param_group',
                        'param_name' => 'group_social', 
                        'params' => array(

                            array(
                                "type" => "textfield",
                                "heading" => esc_html__( "Social Link", 'startnext-toolkit' ),
                                "param_name" => "link",
                            ),
                            array(
                                "type" => "iconpicker",
                                "heading" => esc_html__( "Social Icon", 'startnext-toolkit' ),
                                "param_name" => "socialicon",
                            ),

                        ),
                    )
                    
                )
            ),
            array(
                "type"          => "dropdown",
                "heading"       => esc_html__( "Choose Style", 'startnext-toolkit' ),
                "param_name"    => "style",
                'admin_label'   => true,
                    'value'       => array(
                    'Style - Slider'   => 1,
                    'Style - Card'   => 2
                )
            ),
            array(
                "type"          => "dropdown",
                "heading"       => esc_html__( "Choose Columns ", 'startnext-toolkit' ),
                "param_name"    => "columns",
                'admin_label'   => true,
                    'value'       => array(
                    '1'   => 1,
                    '2'   => 2,
                    '3'   => 3,
                    '4'   => 4
                ),
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
        )
    )   
);