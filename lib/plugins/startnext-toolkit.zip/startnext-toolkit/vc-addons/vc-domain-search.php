<?php
vc_map( 
    array(
        "name" => esc_html__( "Search Domain", 'startnext-toolkit' ),
        "base" => "startnext_search_domain",
        "class" => "",
        "category" => esc_html__( "StartNext", 'startnext-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/startnext-icon.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Title", 'startnext-toolkit' ),
                "param_name" => "title",
            ),
			array(
                "type" => "textfield",
                "heading" => esc_html__( "Search Button", 'startnext-toolkit' ),
                "param_name" => "search_button",
            ),
			array(
                "type" => "textfield",
                "heading" => esc_html__( "Placeholder Text", 'startnext-toolkit' ),
                "param_name" => "placeholder_text",
            ),
            array(
                'type' => 'param_group',
                'param_name' => 'group_domain', 
                "heading" => esc_html__( "Add Domain Item", 'startnext-toolkit' ),
                'params' => array(
                    array(
                        'type' => 'textfield',
                        'heading' => 'Enter your domain type name',
                        'param_name' => 'type',
                    ),
                    array(
                        'type' => 'textfield',
                        'heading' => 'Enter your domain price',
                        'param_name' => 'price',
                    ), 
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Domain Available Text", 'startnext-toolkit' ),
                "param_name" => "available_text",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Domain Unavailable Text", 'startnext-toolkit' ),
                "param_name" => "unavailable_text",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Add Your Extra Class Name", 'startnext-toolkit' ),
                "description" => esc_html__( "Style particular content element differently - add a class name and refer to it in custom CSS.", 'startnext-toolkit' ),
                "param_name" => "custom_class",
            ),
        )
    )   
);