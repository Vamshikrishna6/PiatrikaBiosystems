<?php
function startnext_banner_slider_hosting_shortcode($atts, $content = null){
    extract( shortcode_atts( array(

    ), $atts) );

    $items = vc_param_group_parse_atts($atts['group_sliders']); 
    $domain = 'startnext-toolkit';

    $startnext_banner_slider_hosting_markup ='';
    $startnext_banner_slider_hosting_markup .='

    <div class="hero-slider">';
        foreach($items as $item){
            if (!empty($item)) {  $startnext_banner_slider_hosting_markup .='
                <div class="hosting-main-banner">
                    <div class="d-table">
                        <div class="d-table-cell">
                            <div class="container">
                                <div class="row align-items-center">
                                    <div class="col-lg-6 col-md-12">
                                        <div class="hosting-banner-content">';
                                            if( isset( $item['title'] ) ) { $startnext_banner_slider_hosting_markup .='
                                                <h1>'.esc_html__( $item['title'] ).'</h1>';
                                            } 

                                            if( isset( $item['content'] ) ) { $startnext_banner_slider_hosting_markup .='
                                                '.__(wpautop($item['content']), $domain) .'';
                                            } 

                                            if( isset( $item['btnname'] ) ) {
                                                $btnname = $item['btnname'];

                                                if( $item['type'] == 1 ){
                                                    $link_source = get_page_link($item['link_to_page']); 
                                                } else {
                                                    $link_source = $item['external_link'];
                                                }
                                            }else {
                                                $btnname = '';
                                            }
                                            
                                            if (($link_source != '') && ($btnname != '')) {
                                                $startnext_banner_slider_hosting_markup .='
                                                <a href="'.esc_url($link_source).'" class="btn btn-primary">'.esc_html__($btnname).'</a>';
                                            }
                                            $startnext_banner_slider_hosting_markup .='
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-12">
                                        <div class="slider-image">';
                                            if ( isset( $item['img'] ) ) { 
                                                $side_image = wp_get_attachment_image_src($item['img'], 'large');
                                                $startnext_banner_slider_hosting_markup .='
                                                
                                                <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow fadeInDown bannerrightimg" >';
                                            }
                                            $startnext_banner_slider_hosting_markup .='
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="shape1">
                        <img src="'. get_template_directory_uri() .'/assets/img/shape1.png" alt="'.esc_attr__('shape','startnext-toolkit').'">
                    </div>
                    <div class="shape2 rotateme">
                        <img src="'. get_template_directory_uri() .'/assets/img/shape2.svg" alt="'.esc_attr__('shape','startnext-toolkit').'">
                    </div>
                    <div class="shape3">
                        <img src="'. get_template_directory_uri() .'/assets/img/shape3.svg" alt="'.esc_attr__('shape','startnext-toolkit').'">
                    </div>
                    <div class="shape4">
                        <img src="'. get_template_directory_uri() .'/assets/img/shape4.svg" alt="'.esc_attr__('shape','startnext-toolkit').'">
                    </div>
                    <div class="shape5">
                        <img src="'. get_template_directory_uri() .'/assets/img/shape5.png" alt="'.esc_attr__('shape','startnext-toolkit').'">
                    </div>
                    <div class="shape6 rotateme">
                        <img src="'. get_template_directory_uri() .'/assets/img/shape4.svg" alt="'.esc_attr__('shape','startnext-toolkit').'">
                    </div>
                    <div class="shape7">
                        <img src="'. get_template_directory_uri() .'/assets/img/shape4.svg" alt="'.esc_attr__('shape','startnext-toolkit').'">
                    </div>
                    <div class="shape8 rotateme">
                        <img src="'. get_template_directory_uri() .'/assets/img/shape2.svg" alt="'.esc_attr__('shape','startnext-toolkit').'">
                    </div>
                </div>';
            }
        } $startnext_banner_slider_hosting_markup .='

    </div>';

    return $startnext_banner_slider_hosting_markup;
}
add_shortcode('startnext_banner_slider_hosting', 'startnext_banner_slider_hosting_shortcode');