<?php
function startnext_user_expectation_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'number'        => '100',
        'symble'        => 'K',
        'custom_class'  => '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $domain = 'startnext-toolkit';

    $startnext_user_expectation_markup ='';
    $startnext_user_expectation_markup .='
        <div class="funfact'.esc_attr__($custom_class, $domain).'">
            <h3><span class="odometer" data-count="'.esc_attr__($number, 'startnext-toolkit') .'">'.esc_html__('00','startnext-toolkit').'</span>'.esc_html__($symble,'startnext-toolkit') .'</h3>
            <p>'.esc_html__($title,'startnext-toolkit') .'</p>
        </div>
    ';
    return $startnext_user_expectation_markup;
}
add_shortcode('startnext_user_expectation', 'startnext_user_expectation_shortcode');