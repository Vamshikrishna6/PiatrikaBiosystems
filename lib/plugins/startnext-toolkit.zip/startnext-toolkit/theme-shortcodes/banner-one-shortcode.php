<?php
function startnext_banner_one_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'top_title'         => '',
        'description'   => '',
        'img'           => '',
        'img2'           => '',
        'btnname'       => '',
        'type'     	  	=> 1,
        'link_to_page'  => '',
        'external_link' => '',
        'custom_class'  => '',
        'style'         => '1',
        'shape_remove'  => '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }

    if($type == 1){
        $link_source = get_page_link($link_to_page); 
    } else {
        $link_source = $external_link;
    }

    $side_image = wp_get_attachment_image_src($img, 'full');
    $back_image = wp_get_attachment_image_src($img2, 'full');
    $domain = 'startnext-toolkit';

    if($style == 1){
    $startnext_banner_one_markup ='
    <div class="main-banner'.esc_attr__($custom_class, $domain).'">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="row h-100 justify-content-center align-items-center">
                        <div class="col-lg-5">
                            <div class="hero-content">
                                <h1>'.esc_html__($title,'startnext-toolkit').'</h1>
                                <p>'.esc_html__($description,'startnext-toolkit').'</p>';
                                if (($link_source != '') && ($btnname != '')) {
                                    $startnext_banner_one_markup .='
                                    <a href="'.esc_url($link_source).'" class="btn btn-primary">'.esc_html__($btnname,'startnext-toolkit').'</a>';
                                }
                                $startnext_banner_one_markup .='
                            </div>
                        </div>

                        <div class="col-lg-6 offset-lg-1">';
                            if ($side_image[0] != '') { 
                                $startnext_banner_one_markup .='
                                <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow fadeInDown bannerrightimg" >';
                            }else{
                            $startnext_banner_one_markup .='
                            <div class="banner-image">
                                    <img src="'. get_template_directory_uri() .'/assets/img/banner-image/man.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="'.esc_attr__('man','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/code.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('code','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/carpet.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="'.esc_attr__('carpet','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/bin.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('bin','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/book.png" class="wow bounceIn" data-wow-delay="0.6s" alt="'.esc_attr__('book','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/dekstop.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="'.esc_attr__('dekstop','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/dot.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('dot','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/flower-top-big.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('flower-top-big','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/flower-top.png" class="wow rotateIn" data-wow-delay="0.6s" alt="'.esc_attr__('flower-top','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/keyboard.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('keyboard','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/pen.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('pen','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/table.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('table','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/tea-cup.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="'.esc_attr__('tea-cup','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/headphone.png" class="wow rollIn" data-wow-delay="0.6s" alt="'.esc_attr__('headphone','startnext-toolkit').'">
									<img src="'. get_template_directory_uri() .'/assets/img/banner-image/main-pic.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('main-pic','startnext-toolkit').'">
                             </div>';
                            }
                            $startnext_banner_one_markup .='
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="shape1"><img src="'. get_template_directory_uri() .'/assets/img/shape1.png" alt="'.esc_attr__('shape','startnext-toolkit').'"></div>
        <div class="shape2 rotateme"><img src="'. get_template_directory_uri() .'/assets/img/shape2.svg" alt="'.esc_attr__('shape','startnext-toolkit').'"></div>
        <div class="shape3"><img src="'. get_template_directory_uri() .'/assets/img/shape3.svg" alt="'.esc_attr__('shape','startnext-toolkit').'"></div>
        <div class="shape4"><img src="'. get_template_directory_uri() .'/assets/img/shape4.svg" alt="'.esc_attr__('shape','startnext-toolkit').'"></div>
        <div class="shape5"><img src="'. get_template_directory_uri() .'/assets/img/shape5.png" alt="'.esc_attr__('shape','startnext-toolkit').'"></div>
        <div class="shape6 rotateme"><img src="'. get_template_directory_uri() .'/assets/img/shape4.svg" alt="'.esc_attr__('shape','startnext-toolkit').'"></div>
        <div class="shape7"><img src="'. get_template_directory_uri() .'/assets/img/shape4.svg" alt="'.esc_attr__('shape','startnext-toolkit').'"></div>
        <div class="shape8 rotateme"><img src="'. get_template_directory_uri() .'/assets/img/shape2.svg" alt="'.esc_attr__('shape','startnext-toolkit').'"></div>
    </div>';
    }elseif ($style == 2) {
        $startnext_banner_one_markup .='
        <div class="iot-main-banner'.esc_attr__($custom_class, $domain).'">
            <div class="container">
                <div class="iot-banner-content">
                    <span>'.esc_html__($top_title,'startnext-toolkit').'</span>
                    <h2>'.esc_html__($title,'startnext-toolkit').'</h2>
                    <p>'.esc_html__($description,'startnext-toolkit').'</p>';                
                    if (($link_source != '') && ($btnname != '')) {
                        $startnext_banner_one_markup .='
                        <a href="'.esc_url($link_source).'" class="btn btn-primary">'.esc_html__($btnname,'startnext-toolkit').'</a>';
                    }
                    $startnext_banner_one_markup .='
                </div>

                <div class="iot-banner-image">';
                    if ($side_image[0] != '') { 
                        $startnext_banner_one_markup .='
                        <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow fadeInUp" data-wow-delay="0.8s" >';
                    }

                    if ($back_image[0] != '') { 
                        $startnext_banner_one_markup .='
                        <img src="'.esc_url($back_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow zoomIn" data-wow-delay="0.8s" >';
                    }
                    $startnext_banner_one_markup .='

                </div>

                <div class="animate-border">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>';
    }elseif ($style == 3) {
        $startnext_banner_one_markup .='
        <div class="repair-main-banner'.esc_attr__($custom_class, $domain).'">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="repair-banner-content">
                            <h1>'.esc_html__($title,'startnext-toolkit').'</h1>
                            <p>'.esc_html__($description,'startnext-toolkit').'</p>';                
                            if (($link_source != '') && ($btnname != '')) {
                                $startnext_banner_one_markup .='
                                <a href="'.esc_url($link_source).'" class="btn btn-primary">'.esc_html__($btnname,'startnext-toolkit').'</a>';
                            }
                            $startnext_banner_one_markup .='
                        </div>
                    </div>

                    <div class="col-lg-6">';
                        if ($side_image[0] != '') { 
                            $startnext_banner_one_markup .='
                            <div class="repair-banner-image">
                                <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow fadeInUp" data-wow-delay="0.8s" >';
                                if ($shape_remove == '') { 
                                    $startnext_banner_one_markup .='
                                    <img src="'.get_template_directory_uri().'/assets/img/repair-banner-image/1.png" class="wow zoomIn" data-wow-delay="0.6s" alt="image">
                                    <img src="'.get_template_directory_uri().'/assets/img/repair-banner-image/2.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="image">
                                    <img src="'.get_template_directory_uri().'/assets/img/repair-banner-image/circle.png" class="rotateme" alt="image">';
                                }
                                $startnext_banner_one_markup .='
                            </div>';
                        }
                        $startnext_banner_one_markup .='
                    </div>
                </div>
            </div>
        </div>';
    }
    return $startnext_banner_one_markup;
    
}
add_shortcode('startnext_banner_one', 'startnext_banner_one_shortcode');