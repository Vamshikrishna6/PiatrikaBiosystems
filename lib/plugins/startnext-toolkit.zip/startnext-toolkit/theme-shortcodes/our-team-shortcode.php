<?php
function startnext_our_team_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'name'          => '',
        'designation'   => '',
        'img'           => '',
        'style'         => 1,
        'custom_class'  => '',
        'columns'       => 1,
    ), $atts) );

    if($columns == 1){
        $column = 'col-lg-12 col-md-6';
    }elseif ($columns == 2) {
        $column = 'col-lg-6 col-md-6';
    }elseif ($columns == 3) {
        $column = 'col-lg-4 col-md-6';
    }elseif ($columns == 4) {
        $column = 'col-lg-3 col-md-6';
    }
    

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $domain = 'startnext-toolkit';

    $startnext_our_team_markup ='';

    if ($style == 1) {

    $startnext_our_team_markup .='
    <div class="row m-0'.esc_attr__($custom_class, $domain).'">
        <div class="owl-carousel">';
            $teams = vc_param_group_parse_atts($atts['group_teams']); 
            foreach($teams as $team){
                if (!empty($team)) {
                    if(isset($team['name']) &&  isset($team['designation']) && isset($team['img']) ):
                        $image = wp_get_attachment_image_src($team['img'], 'large');
                        $socials = vc_param_group_parse_atts(($team['group_social'])); 
                        $startnext_our_team_markup .='
                        <div class="col-lg-12">
                            <div class="single-team">
                                <div class="team-image">
                                    <img src="'.esc_url($image[0]).'" alt="'.esc_attr__($team['name'], 'startnext-toolkit').'" class="wow fadeInDown bannerrightimg" >
                                </div>

                                <div class="team-content">
                                    <div class="team-info">
                                        <h3>'.esc_html__($team['name'], 'startnext-toolkit').'</h3>
                                        <span>'.esc_html__($team['designation'], 'startnext-toolkit').'</span>
                                    </div>
                                    <ul>';
                                    foreach($socials as $social){
                                    if (!empty($social)) {
                                    if(isset($social['link']) &&  isset($social['socialicon']) ):  
                                    $startnext_our_team_markup .='
                                    <li><a href="'.esc_attr__($social['link'], 'startnext-toolkit').'"><i class="'.esc_attr__($social['socialicon'], 'startnext-toolkit').'"></i></a></li>';
                                    endif;
                                    }
                                    }
                                    $startnext_our_team_markup .='
                                    </ul>';
                                    if(isset($team['description']) ):
                                    $startnext_our_team_markup .='
                                    <p>'.esc_html__($team['description'], 'startnext-toolkit').'</p>';
                                    endif;
                                    $startnext_our_team_markup .='
                                </div>
                            </div>
                        </div>';
                    endif;
                }
            }
            $startnext_our_team_markup .='
        </div>
    </div>';
    }else{ 
        $startnext_our_team_markup .='
    <div class="row'.esc_attr__($custom_class, $domain).'">';
            $teams = vc_param_group_parse_atts($atts['group_teams']); 
            foreach($teams as $team){
                if (!empty($team)) {
                    if(isset($team['name']) &&  isset($team['designation']) && isset($team['img']) ):
                        $image = wp_get_attachment_image_src($team['img'], 'large');
                        $socials = vc_param_group_parse_atts(($team['group_social'])); 
                        $startnext_our_team_markup .='
                        <div class="'.esc_attr__($column, $domain).'">
                            <div class="single-team">
                                <div class="team-image">
                                    <img src="'.esc_url($image[0]).'" alt="'.esc_attr__($team['name'], 'startnext-toolkit').'" class="wow fadeInDown bannerrightimg" >
                                </div>

                                <div class="team-content">
                                    <div class="team-info">
                                        <h3>'.esc_html__($team['name'], 'startnext-toolkit').'</h3>
                                        <span>'.esc_html__($team['designation'], 'startnext-toolkit').'</span>
                                    </div>
                                    <ul>';
                                    foreach($socials as $social){
                                    if (!empty($social)) {
                                    if(isset($social['link']) &&  isset($social['socialicon']) ):  
                                    $startnext_our_team_markup .='
                                    <li><a href="'.esc_attr__($social['link']).'"><i class="'.esc_attr__($social['socialicon'], 'startnext-toolkit').'"></i></a></li>';
                                    endif;
                                    }
                                    }
                                    $startnext_our_team_markup .='
                                    </ul>';
                                    if(isset($team['description']) ):
                                    $startnext_our_team_markup .='
                                    <p>'.esc_html__($team['description'], 'startnext-toolkit').'</p>';
                                    endif;
                                    $startnext_our_team_markup .='
                                </div>
                            </div>
                        </div>';
                    endif;
                }
            }
            $startnext_our_team_markup .='
    </div>';
    }
    return $startnext_our_team_markup;
}
add_shortcode('startnext_our_team', 'startnext_our_team_shortcode');