<?php
function startnext_pricing_plan_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'name'          => '',
        'price'         => '',
        'duration'      => '',
        'symble'        => '',
        'btnname'       => '',
        'type'     	  	=> 1,
        'icon'     	  	=> '1',
        'style'     	=> 1,
        'link_to_page'  => '',
        'external_link' => '',
        'packageactive' => 'false',
        'custom_class'  => '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    if($type == 1){
        $link_source = get_page_link($link_to_page); 
    } else {
        $link_source = $external_link;
    }
    if($packageactive == 'true'){
        $active_plane = 'active-plan'; 
    } else {
        $active_plane = ''; 
    }
    $items = vc_param_group_parse_atts($atts['group_package_features']); 
    $domain = 'startnext-toolkit';
    $startnext_pricing_plan_markup ='';
    if($style == 1){
    $startnext_pricing_plan_markup .='
    <div class="pricing-table '.esc_attr__($active_plane, $domain).''.esc_attr__($custom_class, $domain).'">
        <div class="pricing-header">
            <h3>'.esc_html__($name, $domain).'</h3>
        </div>
        
        <div class="price">
            <span><sup>'.esc_html__($symble, $domain).'</sup>'.esc_html__($price, $domain).' <span>/'.esc_html__($duration, $domain).'</span></span>
        </div>
        
        <div class="pricing-features">
            <ul>';
            foreach($items as $item){
                if (!empty($item)) {
                    if(isset($item['feature'])):
                        if (isset($item['featuredisable']) && $item['featuredisable']) {
                            $status = '';
                        }else{
                            $status = 'active';
                        }
                        $startnext_pricing_plan_markup .='
                        <li class="'.esc_attr__($status, $domain).'">'.esc_html__($item['feature'], $domain).'</li>';
                    endif;
                }
            }
            $startnext_pricing_plan_markup .='
            </ul>
        </div>
        
        <div class="pricing-footer">';
            if (($link_source != '') && ($btnname != '')) {
                $startnext_pricing_plan_markup .='
                <a href="'.esc_url($link_source).'" class="btn btn-primary">'.esc_html__($btnname,'startnext-toolkit').'</a>';
            }
            $startnext_pricing_plan_markup .='
        </div>
    </div>';
    }else{
        $startnext_pricing_plan_markup .='
        <div class="single-pricing-table '.esc_attr__($custom_class, $domain).'">
            <div class="pricing-header">
                <i class="'.esc_attr($icon, $domain).'"></i>
                <h3>'.esc_html__($name, $domain).'</h3>
            </div>
            
            <div class="price">
                <span><sup>'.esc_html__($symble, $domain).'</sup>'.esc_html__($price, $domain).' <span>/'.esc_html__($duration, $domain).'</span></span>
            </div>
            
            <div class="pricing-features">
                <ul>';
                foreach($items as $item){
                    if (!empty($item)) {
                        if(isset($item['feature'])):
                            if (isset($item['featuredisable']) && $item['featuredisable']) {
                                $status = '';
                            }else{
                                $status = '<i data-feather="check"></i>';
                            }
                            $startnext_pricing_plan_markup .='
                            <li>'.__(wp_kses_post($status), $domain) .' '.esc_html__($item['feature'], $domain).'</li>';
                        endif;
                    }
                }
                $startnext_pricing_plan_markup .='
                </ul>
            </div>
            
            <div class="pricing-footer">';
                if (($link_source != '') && ($btnname != '')) {
                    $startnext_pricing_plan_markup .='
                    <a href="'.esc_url($link_source).'" class="btn btn-primary">'.esc_html__($btnname,'startnext-toolkit').'</a>';
                }
                $startnext_pricing_plan_markup .='
            </div>
        </div>';
    }
    return $startnext_pricing_plan_markup;
}
add_shortcode('startnext_pricing_plan', 'startnext_pricing_plan_shortcode');