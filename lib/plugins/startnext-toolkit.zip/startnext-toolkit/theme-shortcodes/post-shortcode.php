<?php
function startnext_post_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'postcount'   => '3',
        'custom_class'  => '',
        'columns'       => 2,
    ), $atts) );

    if ($columns == 2) {
        $column = 'col-lg-6 col-md-6';
    }elseif ($columns == 3) {
        $column = 'col-lg-4 col-md-6';
    }elseif ($columns == 4) {
        $column = 'col-lg-3 col-md-6';
    }
        
    $domain = 'startnext-toolkit';
    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $startnext_post_markup ='';
    $startnext_post_markup .='
    <div class="row'.esc_attr__($custom_class, $domain).'">';
        $q = new WP_Query(array('orderby' => 'date', 'order' => 'DESC' , 'posts_per_page' => $postcount, 'ignore_sticky_posts' => 1, 'meta_key' => '_thumbnail_id'));
        while($q->have_posts()): $q->the_post();
        $idd = get_the_ID();
        $category_list = get_the_category_list(', ' );
        $startnext_post_markup .='
        <div class="'.esc_attr__($column, $domain).'">
            <div class="single-blog-post ">
                <div class="blog-image">
                    <a href="'.esc_url(get_the_permalink(), $domain).'">
                        <img src="'.esc_url(get_the_post_thumbnail_url(), $domain).'" alt="'.esc_attr__('blog image','startnext-toolkit').'">
                    </a>
                    <div class="date">
                        <i data-feather="calendar"></i>'.esc_html__(get_the_date('F d, Y'), $domain).'
                    </div>
                </div>

                <div class="blog-post-content custom-padding">
                    <h3><a href="'.esc_url(get_the_permalink(), $domain).'">'.esc_html__(get_the_title(), $domain).'</a></h3>

                    <ul>
						<li>
							<i class="fa fa-user"></i>
							<a href="'.esc_url( get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ).'">'.esc_html__(get_the_author(),$domain).'</a>
						</li>
					</ul>

                    <p>'.esc_html__(get_the_excerpt(),$domain).'</p>
					
					<div class="mt-2">
						<a href="'.esc_url(get_the_permalink(), $domain).'" class="read-more-btn">'.esc_html__('Read More', $domain).' <i data-feather="arrow-right"></i> </a>
					</div>
                </div>
            </div>
        </div>';
        endwhile;
        wp_reset_query();
        $startnext_post_markup .='
    </div>
    ';
    return $startnext_post_markup;
}
add_shortcode('startnext_post', 'startnext_post_shortcode');