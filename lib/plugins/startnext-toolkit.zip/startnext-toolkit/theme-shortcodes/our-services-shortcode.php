<?php
function startnext_our_services_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'custom_class'  => '',
        'count'         => '',
        'columns'       => 4,
        'style'         => '1',
        'args'         => '',
    ), $atts) );

    if ($columns == 1) {
        $column = 'col-lg-12 col-md-6';
    }elseif ($columns == 2) {
        $column = 'col-lg-6 col-md-6';
    }elseif ($columns == 3) {
        $column = 'col-lg-4 col-md-6';
    }elseif ($columns == 4) {
        $column = 'col-lg-3 col-md-6';
    }
    
    $args_options = [];
    if ($args) {
        foreach(explode(',', $args) as $argss){
            $args_options[] = get_term_by('slug', $argss, 'service_cat')->term_id;
        }
    }

    if ($args != '') {
        $services_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'services', 'tax_query' => array( array( 'taxonomy' => 'service_cat', 
        'terms' => $args_options, ) ) ) );
    }else{
        $services_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'services',) );
    }

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $domain = 'startnext-toolkit';

    $startnext_our_services_markup ='';
    if ($style == 1) {
        $startnext_our_services_markup .='
        <div class="row '.esc_attr($custom_class, $domain).'">';
            while($services_array->have_posts()): $services_array->the_post();
            $id = get_the_ID();
            // ACF Fields
            $icon           = get_field('service_icon');
            $icon_color     = get_field('service_icon_color');
            $icon_bg_color  = get_field('service_icon_background_color');
            $startnext_our_services_markup .='
        
            <div class="'.esc_attr($column, $domain).'">
                <div class="single-services-box">
                    <div class="icon" style="background: '.esc_attr($icon_bg_color) .';" >';
                    if (empty($icon)) {
                        $startnext_our_services_markup .='
                        <i class="fa fa-cog" style="color: '.esc_attr($icon_color).';" ></i>';
                    }else{
                        $startnext_our_services_markup .='
                        <i class="'.esc_attr($icon) .'" style="color: '.esc_attr($icon_color).';" ></i>';
                    }
                    $startnext_our_services_markup .='
                    </div>
                    <h3><a href="'.get_the_permalink(get_the_ID()).'">'.get_the_title($id) .'</a></h3>
                    <p>'.get_the_excerpt($id) .'</p>
                </div>
            </div>';
            endwhile;
            wp_reset_query();
            $startnext_our_services_markup .='
        </div>';
    }elseif ($style == 2) {
        $startnext_our_services_markup .='
        <div class="row '.esc_attr($custom_class, $domain).'">';
            while($services_array->have_posts()): $services_array->the_post();
            $id = get_the_ID();
            // ACF Fields
            $icon           = get_field('service_icon');
            $icon_color     = get_field('service_icon_color');
            $icon_bg_color  = get_field('service_icon_background_color');
            $startnext_our_services_markup .='

            <div class="col-lg-4 col-md-6">
                <div class="single-repair-box">';
                    if ($icon != '') {
                        $startnext_our_services_markup .='
                        <div class="icon">
                        <i class="'.esc_attr($icon) .'"></i>
                        </div>';
                    }
                    $startnext_our_services_markup .='
                    
                    <h3>'.get_the_title($id) .'</h3>
                    <p>'.get_the_excerpt($id) .'</p>                    
                    <a href="'.get_the_permalink(get_the_ID()).'"><i data-feather="arrow-right"></i></a>';

                    if ($icon != '') {
                        $startnext_our_services_markup .='
                        <div class="back-icon">
                        <i class="'.esc_attr($icon) .'"></i>
                        </div>';
                    }
                    $startnext_our_services_markup .='
                </div>
            </div>';
        endwhile;
        wp_reset_query();
        $startnext_our_services_markup .='
        </div>';
    }elseif ($style == 3) {
        $startnext_our_services_markup .='
        <div class="row '.esc_attr($custom_class, $domain).'">';
            while($services_array->have_posts()): $services_array->the_post();
            $id = get_the_ID();
            // ACF Fields
            $icon  = get_field('service_icon');
            $img   = get_field('service_img');
            $startnext_our_services_markup .='

            <div class="col-lg-4 col-md-6">
                <div class="single-iot-box">';
                    if ($img['url'] != '') {
                        $startnext_our_services_markup .='
                        <div class="icon">
                            <img src="'.esc_url($img['url']).'" alt="'.esc_attr__('image','startnext-toolkit') .'">
                        </div>';
                    }
                    $startnext_our_services_markup .='
                    <h3>'.get_the_title($id) .'</h3>
                    <p>'.get_the_excerpt($id) .'</p>                    
                    <a href="'.get_the_permalink(get_the_ID()).'"><i data-feather="arrow-right"></i></a>
                </div>
            </div>';
        endwhile;
        wp_reset_query();
        $startnext_our_services_markup .='
        </div>';
    }
    
    return $startnext_our_services_markup;
}
add_shortcode('startnext_our_services', 'startnext_our_services_shortcode');