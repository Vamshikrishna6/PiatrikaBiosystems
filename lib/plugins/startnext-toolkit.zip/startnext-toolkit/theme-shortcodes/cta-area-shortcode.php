<?php
function startnext_cta_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'short_desc'    => '',
        'short_desc'    => '',
        'btnname'       => '',
        'type'     	  	=> 1,
        'link_to_page'  => '',
        'external_link' => '',
        'custom_class'  => '',
        'style'         => 1,
        'desc3'         => '',
        'img'           => '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }

    if($type == 1){
        $link_source = get_page_link($link_to_page); 
    } else {
        $link_source = $external_link;
    }

    $side_image = wp_get_attachment_image_src($img, 'full');
    $domain = 'startnext-toolkit';

    $startnext_cta_markup ='';
    if ($style == 1) {
    $startnext_cta_markup .=' 
    <div class="cta-area ptb-80 '.esc_attr__($custom_class, $domain).'">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7 col-md-6">
                    <div class="cta-content">
                        <h3>'.esc_html__($title, $domain).'</h3>
                    </div>
                </div>

                <div class="col-lg-5 col-md-6">
                    <div class="cta-right-content">
                        <div class="hosting-price">
                            <span>'.esc_html__($short_desc, $domain).'</span>
                            <h4>'.esc_html__($short_desc, $domain).'</h4>
                        </div>';
                        if(!$btnname == ''){ $startnext_cta_markup .=' 
                            <div class="buy-btn">
                                <a href="'.esc_url($link_source, $domain).'" class="btn btn-primary">'.esc_html__($btnname, $domain).'</a>
                            </div>';
                        } $startnext_cta_markup .=' 
                    </div>
                </div>
            </div>
        </div>
    </div>';
    }elseif ($style == 2) {
        $startnext_cta_markup .=' 
        <div class="iot-cta-area bg-0f054b'.esc_attr__($custom_class, $domain).'">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">';
                        if ($side_image[0] != '') { 
                            $startnext_cta_markup .='
                            <div class="cta-iot-img">
                                <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow fadeInUp" data-wow-delay="0.6s"" >
                            </div>';
                        }
                        $startnext_cta_markup .='
                    </div>
                    <div class="col-lg-6">
                        <div class="cta-iot-content">
                            <h3>'.esc_html__($title, $domain).'</h3>
                            <p>'.esc_html__($desc3,'startnext-toolkit').'</p>';                
                            if(!$btnname == ''){ $startnext_cta_markup .=' 
                                <div class="buy-btn">
                                    <a href="'.esc_url($link_source, $domain).'" class="btn btn-primary">'.esc_html__($btnname, $domain).'</a>
                                </div>';
                            } $startnext_cta_markup .=' 
                        </div>
                    </div>
                </div>
            </div>
            <div class="circle-box"><img src="'.esc_url(get_template_directory_uri()).'/assets/img/circle.png" alt="image"></div>
            <div class="cta-shape"><img src="'.esc_url(get_template_directory_uri()).'/assets/img/cta-shape.png" alt="image"></div>
        </div>
        ';
    }elseif ($style == 3) {
        $startnext_cta_markup .=' 
        <div class="repair-cta-area bg-0f054b'.esc_attr__($custom_class, $domain).'">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="cta-repair-content">
                            <h3>'.esc_html__($title, $domain).'</h3>
                            <p>'.esc_html__($desc3,'startnext-toolkit').'</p>';                
                            if(!$btnname == ''){ $startnext_cta_markup .=' 
                                <a href="'.esc_url($link_source, $domain).'" class="btn btn-primary">'.esc_html__($btnname, $domain).'</a>
                                ';
                            } $startnext_cta_markup .=' 
                        </div>
                    </div>
                    <div class="col-lg-6">';
                        if ($side_image[0] != '') { 
                            $startnext_cta_markup .='
                            <div class="cta-repair-img">
                                <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow fadeInUp" data-wow-delay="0.6s"" >
                            </div>';
                        }
                        $startnext_cta_markup .='
                    </div>
                    
                </div>
            </div>
            <div class="circle-box"><img src="'.esc_url(get_template_directory_uri()).'/assets/img/circle.png" alt="image"></div>
            <div class="cta-shape"><img src="'.esc_url(get_template_directory_uri()).'/assets/img/cta-shape.png" alt="image"></div>
        </div>
        ';
    }

    return $startnext_cta_markup;
    
}
add_shortcode('startnext_cta', 'startnext_cta_shortcode');