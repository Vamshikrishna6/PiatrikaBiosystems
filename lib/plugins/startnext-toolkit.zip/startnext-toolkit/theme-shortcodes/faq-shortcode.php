<?php
function startnext_faq_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'description'   => '',
        'custom_class'  => '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $items = vc_param_group_parse_atts($atts['group_features']); 
    $domain = 'startnext-toolkit';

    $startnext_faq_markup ='';
    $startnext_faq_markup .='
    <div class="faq-accordion'.esc_attr__($custom_class, $domain).'">
        <ul class="accordion">';
        $count = 1;
            foreach($items as $item){
                if ($count == 1) {
                    $active = 'active';
                    $show = 'show';
                }else {
                    $active = '';
                    $show = '';
                }
                if (!empty($item)) {
                    if(isset($item['title']) &&  isset($item['description']) ):
                        $startnext_faq_markup .='
                        <li class="accordion-item">
                            <a class="accordion-title '.esc_attr__($active, $domain).'" href="javascript:void(0)">'.esc_html__($item['title'],'startnext-toolkit') .'</a>
                            <p class="accordion-content '.esc_attr__($show, $domain).'">'.esc_html__($item['description'],'startnext-toolkit') .'</p>
                        </li>';
                    endif;
                }
                $count++;
            }
            $startnext_faq_markup .='
        </ul>
    </div>';
    return $startnext_faq_markup;
}
add_shortcode('startnext_faq', 'startnext_faq_shortcode');