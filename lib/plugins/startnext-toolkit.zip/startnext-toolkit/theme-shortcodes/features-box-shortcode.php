<?php
function startnext_features_box_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'custom_class'  => '',
        'count'         => '',
        'columns'       => 4,
        'style'         => '',
        'args'         => '',
    ), $atts) );

    if ($columns == 1) {
        $column = 'col-lg-12 col-md-6';
    }elseif ($columns == 2) {
        $column = 'col-lg-6 col-md-6';
    }elseif ($columns == 3) {
        $column = 'col-lg-4 col-md-6';
    }elseif ($columns == 4) {
        $column = 'col-lg-3 col-md-6';
    }

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $domain = 'startnext-toolkit';

    // Nav background color white. 
    if( function_exists('acf_add_options_page') ) {
        $hide_banner = get_field('nav_background_color_white');
        if(  $hide_banner == true ):
            $bg_class = 'boxes-area hosting-boxes-area';
        else:
            $bg_class = '';
        endif;
    }else {
        $bg_class = '';
    }

    $startnext_features_box_markup ='';
    if($style == 1){
    $startnext_features_box_markup .='
    <div class="boxes-area '.esc_attr($bg_class).'">
        <div class="container">
            <div class="row">';
                if (!$args == '') {
                    $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature', 'tax_query' => array( array( 'taxonomy' => 'feature_cat', 'terms' => $args, ) ) ) );
                }else{
                    $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature',) );
                }
            
                while($features_array->have_posts()): $features_array->the_post();
                $id = get_the_ID();
                // ACF Fields
                $icon           = get_field('feature_icon');
                $iconcolor      = get_field('feature_icon_color');
                $iconbg         = get_field('feature_icon_background_color');
                $startnext_features_box_markup .='
            
                <div class="'.esc_attr($column, $domain).'">
                    <div class="single-box'.esc_attr($custom_class, $domain).'">
                        <div class="icon" style="background: '.esc_attr($iconbg).';" >';
                        if (empty($icon)) {
                            $startnext_features_box_markup .='
                            <i class="fa fa-cog" style="color: '.esc_attr($iconcolor).';" ></i>';
                        }else{
                            $startnext_features_box_markup .='
                            <i class="'.esc_attr($icon) .'" style="color: '.esc_attr($iconcolor).';" ></i>';
                        }
                        $startnext_features_box_markup .='
                        </div>
                        <h3><a href="'.get_the_permalink($id).'">'.get_the_title($id) .'</a></h3>
                        <p>'.get_the_excerpt($id) .'</p>
                    </div>
                </div>';
                endwhile;
                wp_reset_query();
                $startnext_features_box_markup .='
            </div>
        </div>
    </div>';
    }elseif($style == 2){
        $startnext_features_box_markup .='
        <div class="container'.esc_attr($boxes_class, $domain).'">
            <div class="row">';
                if (!$args == '') {
                    $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature', 'tax_query' => array( array( 'taxonomy' => 'feature_cat', 'terms' => $args, ) ) ) );
                }else{
                    $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature',) );
                }

                while($features_array->have_posts()): $features_array->the_post();
                $id = get_the_ID();
                // ACF Fields
                $icon           = get_field('feature_icon');
                $iconcolor     = get_field('feature_icon_color');
                $iconbg  = get_field('feature_icon_background_color');
                $startnext_features_box_markup .='
            
                <div class="'.esc_attr($column, $domain).'">
                    <div class="single-features'.esc_attr($custom_class, $domain).'">
                        <div class="icon" style="background: '.esc_attr($iconbg) .';" >';
                        if (empty($icon)) {
                            $startnext_features_box_markup .='
                            <i class="fa fa-cog" style="color: '.esc_attr($iconcolor).';" ></i>';
                        }else{
                            $startnext_features_box_markup .='
                            <i class="'.esc_attr($icon) .'" style="color: '.esc_attr($iconcolor).';" ></i>';
                        }
                        $startnext_features_box_markup .='
                        </div>
                        <h3><a href="'.get_the_permalink($id).'">'.get_the_title($id) .'</a></h3>
                        <p>'.get_the_excerpt($id) .'</p>
                    </div>
                </div>';
                endwhile;
                wp_reset_query();
                $startnext_features_box_markup .='
            </div>
        </div>';
    }elseif($style == 4){
        $startnext_features_box_markup .='
        <div class="row'.esc_attr($boxes_class, $domain).'">';
                if (!$args == '') {
                    $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature', 'tax_query' => array( array( 'taxonomy' => 'feature_cat', 'terms' => $args, ) ) ) );
                }else{
                    $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature',) );
                }

                while($features_array->have_posts()): $features_array->the_post();
                $id = get_the_ID();
                // ACF Fields
                $icon           = get_field('feature_icon');
                $iconcolor      = get_field('feature_icon_color');
                $iconbg         = get_field('feature_icon_background_color');
                $startnext_features_box_markup .='
                <div class="col-lg-4 col-md-6">
                    <div class="single-iot-services">';
                        if ($icon != '') {
                            $startnext_features_box_markup .='
                            <div class="icon">
                                <i class="'.esc_attr($icon) .'" style="color: '.esc_attr($iconcolor).';" ></i>
                            </div>';
                        }
                        $startnext_features_box_markup .='
                        <h3>'.get_the_title($id) .'</h3>
                        <p>'.get_the_excerpt($id) .'</p>
                        <a href="'.get_the_permalink($id).'"><i data-feather="arrow-right"></i></a>
                    </div>
                </div>';
        endwhile;
        wp_reset_query();
        $startnext_features_box_markup .='
        </div>';
    }elseif($style == 5){
        $startnext_features_box_markup .='
        <div class="row'.esc_attr($boxes_class, $domain).'">';
            if (!$args == '') {
                $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature', 'tax_query' => array( array( 'taxonomy' => 'feature_cat', 'terms' => $args, ) ) ) );
            }else{
                $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature',) );
            }
            while($features_array->have_posts()): $features_array->the_post();
            $id = get_the_ID();
            // ACF Fields
            $icon           = get_field('feature_icon');
            $iconcolor      = get_field('feature_icon_color');
            $iconbg         = get_field('feature_icon_background_color');

            $startnext_features_box_markup .='
            <div class="col-lg-4 col-md-6">';
                    if ( has_post_thumbnail() ) { 
                        $image = get_the_post_thumbnail_url();
                    
                        $startnext_features_box_markup .='
                        <div class="single-repair-services" style="background-image: url(\''.$image.'\');">';
                    }else{
                        $startnext_features_box_markup .='
                        <div class="single-repair-services">';
                    }
                    if ($icon != '') {
                        $startnext_features_box_markup .='
                        <div class="icon">
                            <i class="'.esc_attr($icon) .'" style="color: '.esc_attr($iconcolor).';" ></i>
                        </div>';
                    }
                    $startnext_features_box_markup .='
                    <h3>'.get_the_title($id) .'</h3>
                    <p>'.get_the_excerpt($id) .'</p>
                    <a href="'.get_the_permalink($id).'"><i data-feather="arrow-right"></i></a>
                </div>
            </div>';
        endwhile;
        wp_reset_query();
        $startnext_features_box_markup .='
        </div>';

    }else{
    $startnext_features_box_markup .='
        <div class="container">
            <div class="row">';
                if (!$args == '') {
                    $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature', 'tax_query' => array( array( 'taxonomy' => 'feature_cat', 'terms' => $args, ) ) ) );
                }else{
                    $features_array = new WP_Query( array('posts_per_page' => $count, 'post_type' => 'feature',) );
                }
                while($features_array->have_posts()): $features_array->the_post();
                $id = get_the_ID();
                // ACF Fields
                $icon           = get_field('feature_icon');
                $iconcolor     = get_field('feature_icon_color');
                $iconbg  = get_field('feature_icon_background_color');
                $startnext_features_box_markup .='
            
                <div class="'.esc_attr($column, $domain).'">
                    <div class="single-hosting-features'.esc_attr($custom_class, $domain).'">
                        <div class="icon" style="background: '.esc_attr($iconbg) .';" >';
                        if (empty($icon)) {
                            $startnext_features_box_markup .='
                            <i class="fa fa-cog" style="color: '.esc_attr($iconcolor).';" ></i>';
                        }else{
                            $startnext_features_box_markup .='
                            <i class="'.esc_attr($icon) .'" style="color: '.esc_attr($iconcolor).';" ></i>';
                        }
                        $startnext_features_box_markup .='
                        </div>
                        <h3><a href="'.get_the_permalink($id).'">'.get_the_title($id) .'</a></h3>
                        <p>'.get_the_excerpt($id) .'</p>
                    </div>
                </div>';
                endwhile;
                wp_reset_query();
                $startnext_features_box_markup .='
            </div>
        </div>';
    }
    return $startnext_features_box_markup;
}
add_shortcode('startnext_features_box', 'startnext_features_box_shortcode');
