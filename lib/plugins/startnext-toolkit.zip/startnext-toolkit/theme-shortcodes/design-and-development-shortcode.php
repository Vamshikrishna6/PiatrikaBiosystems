<?php
function startnext_design_and_development_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'description'   => '',
        'img'          => '',
        'custom_class'  => '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $items = vc_param_group_parse_atts($atts['group_items']); 
    $side_image = wp_get_attachment_image_src($img, 'large');
    $domain = 'startnext-toolkit';

    $startnext_design_and_development_markup ='';
    $startnext_design_and_development_markup .='

    <div class="row h-100 justify-content-center align-items-center'.esc_attr__($custom_class, $domain).'">';

            if ($side_image[0] != '') { 
                $startnext_design_and_development_markup .='
                <div class="col-lg-6 col-md-12 services-left-image single-left-image">
                    <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/cercle-shape.png" class="bg-image rotateme" alt="'.esc_attr__('shape','startnext-toolkit').'">
                    <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow fadeInUp bannerrightimg" >
                </div>
                ';
            }else{
            $startnext_design_and_development_markup .='

            <div class="col-lg-6 col-md-12 services-left-image">
                <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/big-monitor.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="'.esc_attr__('big-monitor','startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/creative.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('creative','startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/developer.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="'.esc_attr__('developer','startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/flower-top.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('flower-top','startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/small-monitor.png" class="wow bounceIn" data-wow-delay="0.6s" alt="'.esc_attr__('small-monitor','startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/small-top.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="'.esc_attr__('small-top','startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/table.png" class="wow zoomIn" data-wow-delay="0.6s" alt="'.esc_attr__('table','startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/target.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('target','startnext-toolkit').'">
                <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/cercle-shape.png" class="bg-image rotateme" alt="'.esc_attr__('shape','startnext-toolkit').'">

                <img src="'. get_template_directory_uri() .'/assets/img/services-left-image/main-pic.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="'.esc_attr__('main-pic','startnext-toolkit').'">
            </div>';
            }
            $startnext_design_and_development_markup .='

            <div class="col-lg-6 col-md-12 services-content">
                <div class="section-title">
                    <h2>'.esc_html__($title,'startnext-toolkit').'</h2>
                    <div class="bar"></div>
                    <p>'.esc_html__($description,'startnext-toolkit').'</p>
                </div>

                <div class="row">';
                    foreach($items as $item){
                        if (!empty($item)) {
                            if(isset($item['item']) &&  isset($item['icon']) ):
                                $startnext_design_and_development_markup .='
                                <div class="col-lg-6 col-md-6">
                                    <div class="box">
                                        <i class="'.esc_attr__($item['icon'],'startnext-toolkit').'" ></i> '.esc_html__($item['item'],'startnext-toolkit').'
                                    </div>
                                </div>';
                            endif;
                        }
                    }
                    $startnext_design_and_development_markup .='
                </div>
            </div>
        </div>';
    return $startnext_design_and_development_markup;
}
add_shortcode('startnext_design_and_development', 'startnext_design_and_development_shortcode');