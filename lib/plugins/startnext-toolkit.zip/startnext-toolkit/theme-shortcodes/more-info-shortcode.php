<?php
function startnext_more_info_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'description'   => '',
        'img'          => '',
        'custom_class'  => '',
        'btnname'       => '',
        'type'     	  	=> 1,
        'link_to_page'  => '',
        'external_link' => '',
        'style'         => '1',

    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }

    if($type == 1){
        $link_source = get_page_link($link_to_page); 
    } else {
        $link_source = $external_link;
    }


    $side_image = wp_get_attachment_image_src($img, 'full');
    $domain = 'startnext-toolkit';

    $startnext_more_info_markup ='';
    if ($style == 1) {
    $startnext_more_info_markup .='
        <div class="row align-items-center'.esc_attr__($custom_class, $domain).'">
            <div class="col-lg-6 iot-features-content">
                <h3>'.esc_html__($title,'startnext-toolkit').'</h3>
                '.__(wpautop($description), $domain) .'';
                if (($link_source != '') && ($btnname != '')) {
                    $startnext_more_info_markup .='
                    <a href="'.esc_url($link_source).'" class="btn btn-primary">'.esc_html__($btnname,'startnext-toolkit').'</a>';
                }
                $startnext_more_info_markup .='
            </div>

            <div class="col-lg-6 iot-features-image">';
                if ($side_image[0] != '') { 
                    $startnext_more_info_markup .='
                        <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow fadeInUp" data-wow-delay="0.6s" >
                    ';
                }
                $startnext_more_info_markup .='
            </div>
        </div>';
    }elseif ($style == 2) {
        $startnext_more_info_markup .='
        <div class="row align-items-center'.esc_attr__($custom_class, $domain).'">
            <div class="col-lg-6 iot-features-image">';
                if ($side_image[0] != '') { 
                    $startnext_more_info_markup .='
                        <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('hero-img','startnext-toolkit').'" class="wow fadeInUp" data-wow-delay="0.6s" >
                    ';
                }
                $startnext_more_info_markup .='
            </div>
            <div class="col-lg-6 iot-features-content">
                <h3>'.esc_html__($title,'startnext-toolkit').'</h3>
                '.__(wpautop($description), $domain) .'';
                if (($link_source != '') && ($btnname != '')) {
                    $startnext_more_info_markup .='
                    <a href="'.esc_url($link_source).'" class="btn btn-primary">'.esc_html__($btnname,'startnext-toolkit').'</a>';
                }
                $startnext_more_info_markup .='
            </div>
        </div>';
    }
    return $startnext_more_info_markup;
}
add_shortcode('startnext_more_info', 'startnext_more_info_shortcode');