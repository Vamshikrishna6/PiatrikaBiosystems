<?php
function startnext_search_domain_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         	=> '',
        'placeholder_text'  => '',
        'search_button'  	=> '',
        'custom_class'  	=> '',
        'unavailable_text'  => '',
        'available_text'  	=> '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $items = vc_param_group_parse_atts($atts['group_domain']); 

    $text_domain = 'startnext-toolkit';

    $startnext_search_domain_markup ='
    <div class="domain-search-area ptb-80 '.esc_attr__($custom_class, $text_domain).'">

        <div class="container">
            <div class="domain-search-content">
                <h2>'.esc_html__($title, $text_domain).'</h2>
                    <form action="" method="GET">
                        <input type="text" class="form-control" name="domain" placeholder="'.esc_attr_x($placeholder_text, $text_domain).'">';

						if(!$search_button == ''){
							$startnext_search_domain_markup .='
							<button type="submit">'.esc_html__($search_button, $text_domain).'</button>';
						} $startnext_search_domain_markup .='
                    </form>';

                        if(isset($_GET['domain'])){
							$AddToEnd = ".";
                            $domain = $_GET['domain'];
							$domainWithDot = implode(array($domain, $AddToEnd));
                        if ( gethostbyname($domainWithDot) != $domainWithDot ) { 
                            if($unavailable_text == ''){ $startnext_search_domain_markup .='
                                <p class="text-danger">'.wp_kses_post('Sorry,<b style="color:#666666;">', $text_domain).' '.esc_html($domain).'</b> '.wp_kses_post('is unavailable. <br> Please try a different search.', $text_domain).'</p>';
                            }else { $startnext_search_domain_markup .='
                                <p class="text-danger">'.esc_html($domain).' '.wp_kses_post($unavailable_text).'</p>';
                            }
                        }
                        else {
                            if($available_text == ''){ $startnext_search_domain_markup .='
                                <p class="text-success"><b style="color:#666666;">'.esc_html($domain).'</b> '.wp_kses_post('is available!', $text_domain).'</p>';
                            }else { $startnext_search_domain_markup .='
                                <p class="text-success">'.esc_html($domain).' '.wp_kses_post($available_text).'</p>';
                            }
                        }
                    }

                if(!$items == ''){ $startnext_search_domain_markup .='
                <ul class="domain-price">';
                    foreach($items as $item){ 
                        if(isset($item['type']) &&  isset($item['price']) ):
                            $startnext_search_domain_markup .='  
                            <li>'.esc_html__($item['type'],'startnext-toolkit') .'<br>'.esc_html__($item['price'],'startnext-toolkit') .'</li>';
                        endif;
                    } 
                    $startnext_search_domain_markup .='
                </ul>';
                }
                $startnext_search_domain_markup .='
            </div>
        </div>
    </div>';

    return $startnext_search_domain_markup;
    
}
add_shortcode('startnext_search_domain', 'startnext_search_domain_shortcode');