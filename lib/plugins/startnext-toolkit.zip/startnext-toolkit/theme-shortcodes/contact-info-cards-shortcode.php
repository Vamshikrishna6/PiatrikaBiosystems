<?php
function startnext_contact_info_cards_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'addresstitle'  => '',
        'addressicon'   => '',
        'phonetitle'    => '',
        'phoneicon'     => '',
        'emailtitle'    => '',
        'emailicon'     => '',
        'custom_class'  => '',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }

    $group_email    = vc_param_group_parse_atts($atts['group_email']); 
    $group_address  = vc_param_group_parse_atts($atts['group_address']); 
    $group_phone    = vc_param_group_parse_atts($atts['group_phone']); 
    $domain = 'startnext-toolkit';

    $startnext_contact_info_cards_markup ='';
    $startnext_contact_info_cards_markup .='
    <div class="startnext'.esc_attr__($custom_class, $domain).'">    
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="contact-info-box">
                    <div class="icon">
                        <i class="'.esc_attr__($emailicon, $domain).'" ></i>
                    </div>
                    <h3>'.esc_html__($emailtitle, $domain).'</h3>';
                        foreach($group_email as $item){
                            if (!empty($item)) {
                                if(isset($item['address'])  ):
                                    $startnext_contact_info_cards_markup .='
                                    <p><a href="mailto:'.__($item['address'], $domain).'">'.esc_html__($item['address'], $domain).'</a></p>';
                                endif;
                            }
                        }
                        $startnext_contact_info_cards_markup .='
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="contact-info-box">
                    <div class="icon">
                    <i class="'.esc_attr__($addressicon, $domain).'" ></i>
                    </div>
                    <h3>'.esc_html__($addresstitle, $domain).'</h3>';
                    foreach($group_address as $item){
                        if (!empty($item)) {
                            if(isset($item['address'])  ):
                                $startnext_contact_info_cards_markup .='
                                <p>'.esc_html__($item['address'], $domain).'</p>';
                            endif;
                        }
                    }
                    $startnext_contact_info_cards_markup .='
                </div>
            </div>

            <div class="col-lg-4 col-md-6 offset-lg-0 offset-md-3">
                <div class="contact-info-box">
                    <div class="icon">
                    <i class="'.esc_attr__($phoneicon, $domain).'" ></i>
                    </div>
                    <h3>'.esc_html__($phonetitle, $domain).'</h3>';
                    foreach($group_phone as $item){
                        if (!empty($item)) {
                            if(isset($item['address'])  ):
                                $startnext_contact_info_cards_markup .='
                                <p><a href="callto:'.__(str_replace(' ', '', $item['address']), $domain).'">'.esc_html__($item['address'], $domain).'</a></p>';
                            endif;
                        }
                    }
                    $startnext_contact_info_cards_markup .='
                </div>
            </div>
        </div>
    </div>';
    return $startnext_contact_info_cards_markup;
}
add_shortcode('startnext_contact_info_cards', 'startnext_contact_info_cards_shortcode');