<?php
function startnext_about_us_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'sm_title'      => '',
        'img'           => '',
        'img2'          => '',
        'img3'          => '',
        'img4'          => '',
        'img5'          => '',
        'custom_class'  => '',
        'style'         => '1',
    ), $atts) );

    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $items = vc_param_group_parse_atts($atts['group_about_card']); 
    $items2 = vc_param_group_parse_atts($atts['group_about_card2']); 
    $side_image = wp_get_attachment_image_src($img, 'full');
    $side_image2 = wp_get_attachment_image_src($img2, 'full');
    $side_image3 = wp_get_attachment_image_src($img3, 'full');
    $side_image4 = wp_get_attachment_image_src($img4, 'full');
    $side_image5 = wp_get_attachment_image_src($img5, 'full');

    $domain = 'startnext-toolkit';

    $startnext_about_us_markup ='';
    if ($style == 1) {
        $startnext_about_us_markup .='
        <div class="startnext'.esc_attr__($custom_class, $domain).'">    
            <div class="row'.esc_attr__($custom_class, $domain).'">
                <div class="col-lg-6 col-md-12">
                    <div class="about-image">
                        <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('image', $domain).'">
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="about-content">
                        <div class="section-title">
                            <h2>'.esc_html__($title, $domain).'</h2>
                            <div class="bar"></div>
                            '.__(wpautop($content), $domain) .'
                    </div>
                </div>
            </div>

            <div class="about-inner-area">
                <div class="row">';
                    foreach($items as $item){
                        if (!empty($item)) {
                            if(isset($item['title']) &&  isset($item['description']) ):
                                $startnext_about_us_markup .='
                                <div class="col-lg-4 col-md-6">
                                    <div class="about-text">
                                        <h3>'.esc_html__($item['title'],'startnext-toolkit').'</h3>
                                        <p>'.esc_html__($item['description'],'startnext-toolkit').'</p>
                                    </div>
                                </div>';
                            endif;
                        }
                    }
                    $startnext_about_us_markup .='
                </div>
            </div>
        </div>
        ';
    }elseif ($style == 2) {
        $startnext_about_us_markup .='
        <div class="startnext'.esc_attr__($custom_class, $domain).'">    
            <div class="row">
                <div class="col-lg-6">
                    <div class="repair-about-content">
                        <span class="sub-title">'.esc_html__($sm_title, $domain).'</span>
                        <h2>'.esc_html__($title, $domain).'</h2>
                        '.__(wpautop($content), $domain) .'

                        <ul>';
                            foreach($items2 as $item){
                                if (!empty($item)) {
                                    if(isset($item['title'])):
                                        $startnext_about_us_markup .='
                                        <li><span><i data-feather="check"></i> '.esc_html__($item['title'],'startnext-toolkit').'</span></li>';
                                    endif;
                                }
                            }
                            $startnext_about_us_markup .='
                        </ul>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="repair-about-image">';
                        if ($side_image2[0] != '') { 
                            $startnext_about_us_markup .='
                            <img src="'.esc_url($side_image2[0]).'" alt="'.esc_attr__('img','startnext-toolkit').'" class="wow fadeInDown" >';
                        }
                        if ($side_image[0] != '') { 
                            $startnext_about_us_markup .='
                            <img src="'.esc_url($side_image[0]).'" alt="'.esc_attr__('img','startnext-toolkit').'" class="wow zoomIn" >';
                        }
                        if ($side_image3[0] != '') { 
                            $startnext_about_us_markup .='
                            <img src="'.esc_url($side_image3[0]).'" alt="'.esc_attr__('img','startnext-toolkit').'" class="wow fadeInUp" >';
                        }
                        if ($side_image4[0] != '') { 
                            $startnext_about_us_markup .='
                            <img src="'.esc_url($side_image4[0]).'" alt="'.esc_attr__('img','startnext-toolkit').'">';
                        }
                        if ($side_image5[0] != '') { 
                            $startnext_about_us_markup .='
                            <img src="'.esc_url($side_image5[0]).'" alt="'.esc_attr__('img','startnext-toolkit').'">';
                        }
                        $startnext_about_us_markup .='
                    </div>
                </div>
            </div>    
        </div>    
    </div>';
    }

    return $startnext_about_us_markup;
}
add_shortcode('startnext_about_us', 'startnext_about_us_shortcode');