<?php
function startnext_section_title_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'description'   => '',
        'custom_class'  => '',
    ), $atts) );
    if ($custom_class != '') {
        $custom_class = ' '.$custom_class;
    }
    $domain = 'startnext-toolkit';

    $startnext_section_title_markup ='';
    $startnext_section_title_markup .='
        <div class="section-title'.esc_attr__($custom_class, $domain).'">
            <h2>'.esc_html__($title,'startnext-toolkit') .'</h2>
            <div class="bar"></div>
            <p>'.esc_html__($description, 'startnext-toolkit') .'</p>
        </div>
    ';
    return $startnext_section_title_markup;
}
add_shortcode('startnext_section_title', 'startnext_section_title_shortcode');