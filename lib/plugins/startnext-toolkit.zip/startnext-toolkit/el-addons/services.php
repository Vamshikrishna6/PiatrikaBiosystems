<?php
/**
 * Services Widget
 */

namespace Elementor;
class StartNext_Services extends Widget_Base {

	public function get_name() {
        return 'Services';
    }

	public function get_title() {
        return __( 'Services', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-tools';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'services_section',
			[
				'label' => __( 'Services', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Choose Style', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( 'Style One', 'startnext-toolkit' ),
                        2   => __( 'Style Two', 'startnext-toolkit' ),
                        3   => __( 'Style Three', 'startnext-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );

            $this->add_control(
                'columns',
                [
                    'label' => __( 'Choose Columns', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( '1', 'startnext-toolkit' ),
                        2   => __( '2', 'startnext-toolkit' ),
                        3   => __( '3', 'startnext-toolkit' ),
                        4   => __( '4', 'startnext-toolkit' ),
                    ],
                    'default' => 4,
                ]
            );

            $this->add_control(
                'cat_name',
                [
                    'label' => __( 'Choose Category', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => startnext_toolkit_get_page_services_cat_el(),
                ]
            );

            $this->add_control(
                'order',
                [
                    'label' => __( 'Services Order By', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'DESC'      => __( 'DESC', 'startnext-toolkit' ),
                        'ASC'       => __( 'ASC', 'startnext-toolkit' ),
                    ],
                    'default' => 'DESC',
                ]
            );

            $this->add_control(
                'count',
                [
                    'label' => __( 'Post Per Page', 'startnext-toolkit' ),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 4,
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'service_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-services-box h3 a, .single-repair-box h3, single-iot-box h3' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-services-box h3, .single-repair-box h3, single-iot-box h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Content Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-services-box p, .single-repair-box p, single-iot-box p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'content_size',
                [
                    'label' => __( 'Content Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 30,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-services-box p, .single-repair-box p, single-iot-box p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Card Columns
        $columns = $settings['columns'];
        if ($columns == 1) {
            $column = 'col-lg-12 col-md-6';
        }elseif ($columns == 2) {
            $column = 'col-lg-6 col-md-6';
        }elseif ($columns == 3) {
            $column = 'col-lg-4 col-md-6';
        }elseif ($columns == 4) {
            $column = 'col-lg-3 col-md-6';
        }
        
        // Feature Query
        if( $settings['cat_name'] != '' ) {
            $args = array(
                'post_type'     => 'services',
                'posts_per_page'=> $settings['count'],
                'order'         => $settings['order'],
                'tax_query'     => array(
                    array(
                        'taxonomy'      => 'service_cat',
                        'field'         => 'slug',
                        'terms'         => $settings['cat_name'],
                        'hide_empty'    => false
                    )
                )
            );
        } else {
            $args = array(
                'post_type'         => 'services',
                'posts_per_page'    => $settings['count'],
                'order'             => $settings['order']
            );
        }
        $services_array = new \WP_Query( $args ); 
        ?>

        <?php if( $settings['card_style']  == 1 ): ?>
            <div class="container">
                <div class="row ">
                    <?php
                    while($services_array->have_posts()): 
                        $services_array->the_post();

                        // ACF Fields
                        $icon           = get_field('service_icon');
                        $icon_color     = get_field('service_icon_color');
                        $icon_bg_color  = get_field('service_icon_background_color');
                        ?>
                        <div class="<?php echo esc_attr( $column );?>">
                            <div class="single-services-box">
                                <div class="icon" style="background: <?php echo esc_attr( $icon_bg_color ); ?>;" >
                                    <i class="<?php echo esc_attr( $icon ); ?>" style="color: <?php echo esc_attr( $icon_color ); ?>;" ></i>
                                </div>
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                <p><?php the_excerpt(); ?></p>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 2 ): ?>
            <div class="container">
                <div class="row">
                    <?php
                    while($services_array->have_posts()): 
                        $services_array->the_post();

                        // ACF Fields
                        $icon  = get_field('service_icon');
                        ?>
                        <div class="<?php echo esc_attr( $column );?>">
                            <div class="single-repair-box">
                                <div class="icon">
                                    <i class="<?php echo esc_attr( $icon ); ?>"></i>
                                </div>
                                
                                <h3><?php the_title(); ?></h3>
                                <p><?php the_excerpt(); ?></p>                    
                                <a href="<?php the_permalink(); ?>"><i data-feather="arrow-right"></i></a>
                                <div class="back-icon">
                                    <i class="<?php echo esc_attr( $icon ); ?>">"></i>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 3 ): ?>
            <div class="container">
                <div class="row">
                    <?php
                    while($services_array->have_posts()): 
                        $services_array->the_post();

                        // ACF Fields
                        $icon  = get_field('service_icon');
                        $img   = get_field('service_img');
                        ?>
                        <div class="<?php echo esc_attr( $column );?>">
                            <div class="single-iot-box">
                                <div class="icon">
                                    <?php if( $img['url'] != '' ): ?>
                                        <img src="<?php echo esc_url( $img['url'] ); ?>" alt="<?php the_title(); ?>">
                                    <?php  endif; ?>
                                </div>
                                
                                <h3><?php the_title(); ?></h3>
                                <p><?php the_excerpt(); ?></p>                    
                                <a href="<?php the_permalink(); ?>"><i data-feather="arrow-right"></i></a>  
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>
        

        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Services );
?>

