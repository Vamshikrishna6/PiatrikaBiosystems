<?php
/**
 * Features Widget
 */

namespace Elementor;
class StartNext_Features extends Widget_Base {

	public function get_name() {
        return 'Features';
    }

	public function get_title() {
        return __( 'Features', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-info-box';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'features_section',
			[
				'label' => __( 'Features', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Choose Style', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( 'Top Icon', 'startnext-toolkit' ),
                        6   => __( 'Top Icon(with hosting banner)', 'startnext-toolkit' ),
                        2   => __( 'Left Icon', 'startnext-toolkit' ),
                        3   => __( 'Top Center', 'startnext-toolkit' ),
                        4   => __( 'Icon Center with Gradient Background', 'startnext-toolkit' ),
                        5   => __( 'Icon Center with Gradient Color and Background Image', 'startnext-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );

            $this->add_control(
                'columns',
                [
                    'label' => __( 'Choose Columns', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( '1', 'startnext-toolkit' ),
                        2   => __( '2', 'startnext-toolkit' ),
                        3   => __( '3', 'startnext-toolkit' ),
                        4   => __( '4', 'startnext-toolkit' ),
                    ],
                    'default' => 4,
                ]
            );

            $this->add_control(
                'cat_name',
                [
                    'label' => __( 'Choose Category', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => startnext_toolkit_get_page_feature_cat_el(),
                ]
            );

            $this->add_control(
                'order',
                [
                    'label' => __( 'Features Order By', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'DESC'      => __( 'DESC', 'startnext-toolkit' ),
                        'ASC'       => __( 'ASC', 'startnext-toolkit' ),
                    ],
                    'default' => 'DESC',
                ]
            );

            $this->add_control(
                'count',
                [
                    'label' => __( 'Post Per Page', 'startnext-toolkit' ),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 4,
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'feature_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .boxes-area .single-box h3 a, .single-repair-services h3, .single-iot-services h3' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .boxes-area .single-box h3, .single-repair-services h3, .single-iot-services h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Content Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .boxes-area .single-box p, .single-repair-services p, .single-iot-services p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'content_size',
                [
                    'label' => __( 'Content Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 30,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .boxes-area .single-box p, .single-repair-services p, .single-iot-services p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'border_color',
                [
                    'label' => __( 'Border Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .boxes-area  .single-box, .single-repair-services .icon, .single-iot-services .icon' => 'border-color: {{VALUE}}',
                    ],
                ]
            );

        $this->end_controls_section();


    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Card Columns
        $columns = $settings['columns'];
        if ($columns == 1) {
            $column = 'col-lg-12 col-md-6';
        }elseif ($columns == 2) {
            $column = 'col-lg-6 col-md-6';
        }elseif ($columns == 3) {
            $column = 'col-lg-4 col-md-6';
        }elseif ($columns == 4) {
            $column = 'col-lg-3 col-md-6';
        }
        
        // Feature Query
        if( $settings['cat_name'] != '' ) {
            $args = array(
                'post_type'     => 'feature',
                'posts_per_page'=> $settings['count'],
                'order'         => $settings['order'],
                'tax_query'     => array(
                    array(
                        'taxonomy'      => 'feature_cat',
                        'field'         => 'slug',
                        'terms'         => $settings['cat_name'],
                        'hide_empty'    => false
                    )
                )
            );
        } else {
            $args = array(
                'post_type'         => 'feature',
                'posts_per_page'    => $settings['count'],
                'order'             => $settings['order']
            );
        }
        $features_array = new \WP_Query( $args ); 

        if( $settings['card_style'] == 6 ):
            $class = 'boxes-area hosting-boxes-area';
        else:
            $class = 'boxes-area';
        endif;        
        
        ?>

        <?php if( $settings['card_style']  == 1 || $settings['card_style']  == 6 ): ?>
            <div class="<?php echo esc_attr($class); ?>">
                <div class="container">
                    <div class="row">
                        <?php
                        while($features_array->have_posts()): 
                            $features_array->the_post();

                            // ACF Fields
                            $icon           = get_field('feature_icon');
                            $icon_color     = get_field('feature_icon_color');
                            $icon_bg_color  = get_field('feature_icon_background_color');
                            ?>
                            <div class="<?php echo esc_attr($column); ?>">
                                <div class="single-box">
                                    <div class="icon" style="background: <?php echo esc_attr($icon_bg_color); ?>;">
                                        <i class="<?php echo esc_attr($icon); ?>" style="color: <?php echo esc_attr($icon_color); ?>;"></i>
                                    </div>
                                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                    <p><?php the_excerpt(); ?></p>
                                </div>
                            </div>
                        <?php endwhile; ?>
                        <?php wp_reset_query(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 2 ): ?>
            <div class="container">
                <div class="row">
                    <?php
                    while( $features_array->have_posts()): $features_array->the_post();
                        // ACF Fields
                        $icon           = get_field('feature_icon');
                        $icon_color     = get_field('feature_icon_color');
                        $icon_bg_color  = get_field('feature_icon_background_color');
                    ?>
                        <div class="<?php echo esc_attr($column); ?>">
                            <div class="single-features">
                                <div class="icon" style="background: <?php echo esc_attr($icon_bg_color); ?>;">
                                    <i class="<?php echo esc_attr($icon); ?>" style="color: <?php echo esc_attr($icon_color); ?>;"></i>
                                </div>
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                <p><?php the_excerpt(); ?></p>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 3 ): ?>
            <div class="container">
                <div class="row">
                    <?php
                    while( $features_array->have_posts()): $features_array->the_post();
                        // ACF Fields
                        $icon           = get_field('feature_icon');
                        $icon_color     = get_field('feature_icon_color');
                        $icon_bg_color  = get_field('feature_icon_background_color');
                    ?>
                        <div class="<?php echo esc_attr($column); ?>">
                            <div class="single-hosting-features">
                                <div class="icon" style="background: <?php echo esc_attr($icon_bg_color); ?>;">
                                    <i class="<?php echo esc_attr($icon); ?>" style="color: <?php echo esc_attr($icon_color); ?>;"></i>
                                </div>
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                <p><?php the_excerpt(); ?></p>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 5 ): ?>
            <div class="container">
                <div class="row">
                    <?php
                    while( $features_array->have_posts()): $features_array->the_post();
                        // ACF Fields
                        $icon           = get_field('feature_icon');
                        $icon_color     = get_field('feature_icon_color');
                        $icon_bg_color  = get_field('feature_icon_background_color');
                        ?>
                        <div class="<?php echo esc_attr($column); ?>">
                            <div class="single-repair-services" style="background-image: url('<?php the_post_thumbnail_url(); ?>');">
                                <?php if( $icon != '' ): ?>
                                    <div class="icon">
                                        <i class="<?php echo esc_attr($icon); ?>" style="color: <?php echo esc_attr($icon_color); ?>;" ></i>
                                    </div>
                                <?php endif; ?>
                                <h3><?php the_title(); ?></h3>
                                <p><?php the_excerpt(); ?></p>
                                <a href="<?php the_permalink(); ?>"><i data-feather="arrow-right"></i></a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 4 ): ?>
            <div class="container">
                <div class="row">
                    <?php
                    while( $features_array->have_posts()): $features_array->the_post();
                        // ACF Fields
                        $icon           = get_field('feature_icon');
                        $icon_color     = get_field('feature_icon_color');
                        $icon_bg_color  = get_field('feature_icon_background_color');
                        ?>
                        <div class="<?php echo esc_attr($column); ?>">
                            <div class="single-iot-services">
                                <?php if( $icon != '' ): ?>
                                    <div class="icon">
                                        <i class="<?php echo esc_attr($icon); ?>" style="color: <?php echo esc_attr($icon_color); ?>;" ></i>
                                    </div>
                                <?php endif; ?>
                                <h3><?php the_title(); ?></h3>
                                <p><?php the_excerpt(); ?></p>
                                <a href="<?php the_permalink(); ?>"><i data-feather="arrow-right"></i></a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Features );
?>

