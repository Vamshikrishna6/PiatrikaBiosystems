<?php
/**
 * Testimonial Widget
 */

namespace Elementor;
class StartNext_Testimonial extends Widget_Base {

	public function get_name() {
        return 'Testimonial';
    }

	public function get_title() {
        return __( 'Testimonial', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-testimonial';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Choose Style', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( 'Style One', 'startnext-toolkit' ),
                        2   => __( 'Style Two', 'startnext-toolkit' ),
                        3   => __( 'Style Three', 'startnext-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );

            $this->add_control(
                'testimonial_items',
                [
                    'label' => esc_html__('Slider Item', 'startnext-toolkit'),
                    'type' => Controls_Manager::REPEATER,
                    'default' => [
                        [ 'name' => esc_html__(' Item #1', 'startnext-toolkit') ],
            
                    ],
                    'fields' => [
                        [
                            'name'  => 'image',
                            'label' => __( 'Image', 'startnext-toolkit' ),
                            'type' => Controls_Manager::MEDIA,
                        ],
                
                        [
                            'name' => 'name',
                            'label' => esc_html__('Name', 'startnext-toolkit'),
                            'type' => Controls_Manager::TEXT,
                            'default' => esc_html__('Steven Smith', 'startnext-toolkit'),
                            'label_block' => true,
                        ],
                        [
                            'name' => 'designation',
                            'label' => esc_html__('Designation', 'startnext-toolkit'),
                            'type' => Controls_Manager::TEXT,
                            'default' => esc_html__('CEO at ThemeForest', 'startnext-toolkit'),
                            'label_block' => true,
                        ],
                        [
                            'name' => 'feedback',
                            'label' => esc_html__('Description', 'startnext-toolkit'),
                            'type' => Controls_Manager::TEXTAREA,
                            'default' => esc_html__('Lorem Ipsum is simply dummy text of printing Lorem Ipsum has been the du industrys standard dummy text ever since the 1500s.', 'startnext-toolkit'),
                            'label_block' => true,
                        
                        ],
                    ],
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section(
			'testimonial_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'main_color',
                [
                    'label' => __( 'Main Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .feedback-slides .client-feedback .single-feedback .client-img img, .client-thumbnails .next-arrow:hover, .feedback-slides .client-thumbnails .item .img-fill img' => 'border-color: {{VALUE}}',
                        '{{WRAPPER}} .client-thumbnails .next-arrow::before' => 'background: {{VALUE}}',
                        '{{WRAPPER}} .testimonials-slides.owl-theme .owl-dots .owl-dot.active span::before' => 'background-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'name_color',
                [
                    'label' => __( 'Name Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .feedback-slides .client-feedback .single-feedback h3, .single-feedback-item .client-info .title h3, .single-repair-feedback .client-img h3' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'name_size',
                [
                    'label' => __( 'Name Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .feedback-slides .client-feedback .single-feedback h3, .single-feedback-item .client-info .title h3, .single-repair-feedback .client-img h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'designation_color',
                [
                    'label' => __( 'Designation Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .feedback-slides .client-feedback .single-feedback span, .single-feedback-item .client-info .title span, .single-repair-feedback .client-img span' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'designation_size',
                [
                    'label' => __( 'Designation Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .feedback-slides .client-feedback .single-feedback span, .single-feedback-item .client-info .title span, .single-repair-feedback .client-img span' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'feedback_color',
                [
                    'label' => __( 'Feedback Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .feedback-slides .client-feedback .single-feedback p, .single-feedback-item p, .single-repair-feedback p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'feedback_size',
                [
                    'label' => __( 'Feedback Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .feedback-slides .client-feedback .single-feedback p, .single-feedback-item p, .single-repair-feedback p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {

        $settings       = $this->get_settings_for_display();
        $slider         = $settings['testimonial_items'];
        $card_style     = $settings['card_style'];

        ?>
        <?php if( $card_style == 1 ): ?>
            <div class="feedback-slides">
                <div class="client-feedback">
                    <div>
                        <?php foreach( $slider as $item ): ?>
                            <div class="item">
                                <div class="single-feedback">
                                    <div class="client-img">
                                        <?php if($item['image']['url']): ?>
                                            <img src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                        <?php endif; ?>
                                    </div>
                                    <h3><?php echo esc_attr( $item['name'] ); ?></h3>
                                    <span><?php echo esc_attr( $item['designation'] ); ?></span> 
                                    <p><?php echo esc_attr( $item['feedback'] ); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="client-thumbnails">
                    <div>
                        <?php foreach( $slider as $item ): ?>
                            <div class="item">
                                <?php if($item['image']['url']): ?>
                                    <div class="img-fill"> <img src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>"></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <button class="prev-arrow slick-arrow">
                        <i data-feather="arrow-left"></i>
                    </button>
                    
                    <button class="next-arrow slick-arrow">
                        <i data-feather="arrow-right"></i>
                    </button>
                </div>
            </div>
        <?php elseif( $card_style == 2 ): ?>
            <div class="testimonials-slides">
                <?php foreach( $slider as $item ): ?>
                    <div class="single-feedback-item">
                        <div class="client-info align-items-center">
                            <div class="image">
                                <?php if($item['image']['url']): ?>
                                    <img src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                <?php endif; ?>
                            </div>

                            <div class="title">
                                <h3><?php echo esc_attr( $item['name'] ); ?></h3>
                                <span><?php echo esc_attr( $item['designation'] ); ?></span>
                            </div>
                        </div>

                        <p><?php echo esc_attr( $item['feedback'] ); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if( $card_style == 3 ): ?>
            <div class="feedback-slides">
                <div class="client-feedback">
                    <div>
                        <?php foreach( $slider as $item ): ?>
                            <div class="item">
                                <div class="single-repair-feedback">
                                    <div class="client-img">
                                        <?php if($item['image']['url']): ?>
                                            <img src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                        <?php endif; ?>
                                        <h3><?php echo esc_attr( $item['name'] ); ?></h3>
                                        <span><?php echo esc_attr( $item['designation'] ); ?></span>
                                    </div>
                                    <p><?php echo esc_attr( $item['feedback'] ); ?></p>
                                    
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="client-thumbnails">
                    <div>
                        <?php foreach( $slider as $item ): ?>
                            <div class="item">
                                <?php if($item['image']['url']): ?>
                                    <div class="img-fill"> <img src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>"></div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <button class="prev-arrow slick-arrow">
                        <i data-feather="arrow-left"></i>
                    </button>
                    
                    <button class="next-arrow slick-arrow">
                        <i data-feather="arrow-right"></i>
                    </button>
                </div>
            </div>
        <?php endif; ?>
        <?php
	}
	protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Testimonial );
?>

