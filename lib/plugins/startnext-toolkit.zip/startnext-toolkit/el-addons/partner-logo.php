<?php
/**
 * Partner Logo Slider Widget
 */

namespace Elementor;
class StartNext_Partner_Logo extends Widget_Base {

	public function get_name() {
        return 'Partner_Logo';
    }

	public function get_title() {
        return __( 'Partner Logo Slider', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-logo';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'partner_section',
			[
				'label' => __( 'Partner Logo Control', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'logos',
                [
                    'type'    => Controls_Manager::REPEATER,
                    'label'   => esc_html__( 'Add Partner Logo', 'startnext-toolkit' ),			                 
                    'fields'  => array(		
                        array(
                            'type'    => Controls_Manager::URL,
                            'name'    => 'logo_link',
                            'label'   => esc_html__( 'Logo Link', 'startnext-toolkit' ),
                        ),			
                        array(
                            'type'    => Controls_Manager::MEDIA,
                            'name'    => 'logo',
                            'label'   => esc_html__( 'Logo', 'startnext-toolkit' ),
                        ),
                        array(
                            'type'    => Controls_Manager::MEDIA,
                            'name'    => 'hover_logo',
                            'label'   => esc_html__( 'Hover Logo', 'startnext-toolkit' ),
                        ),
                    ),	
                ]			
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'partner_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'background_color',
                [
                    'label' => __( 'Background Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .iot-partner-area .bg-f9fafb' => 'background: {{VALUE}}',
                    ],
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="partner-slides">
            <?php foreach( $settings['logos'] as $item ): ?>
                <div class="col-lg-12 col-md-12">
                    <div class="single-iot-partner">
                        <a href="<?php echo esc_url( $item['logo_link']['url'] ); ?>">
                            <img src="<?php echo esc_url( $item['logo']['url'] ); ?>" alt="<?php echo esc_attr__( 'Partner Logo', 'startnext-toolkit' ); ?>">
                            <img src="<?php echo esc_url( $item['hover_logo']['url'] );?>" alt="<?php echo esc_attr__( 'Partner Logo', 'startnext-toolkit' ); ?>">
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
	}
	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Partner_Logo );
?>

