<?php
/**
 *CTA Widget
 */

namespace Elementor;
class StartNext_CTA extends Widget_Base {

	public function get_name() {
        return 'StartNext_CTA';
    }

	public function get_title() {
        return __( 'CTA Area', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-tel-field';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_CTA_Area',
			[
				'label' => __( 'StartNext CTA Controls', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Choose Style', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( 'Style - 1', 'startnext-toolkit' ),
                        2   => __( 'Style - 2', 'startnext-toolkit' ),
                        3   => __( 'Style - 3', 'startnext-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('We will help you get back to work', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'description',
                [
                    'label' => __( 'Description', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXTAREA,
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'CTA Image', 'startnext-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );

            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Contact Us', 'startnext-toolkit'),
                ]
            );

            $this->add_control(
                'button_link',
                [
                    'label' => __( 'Button Link', 'startnext-toolkit' ),
                    'type' => Controls_Manager::URL,
                ]
            );
           

        $this->end_controls_section();

        $this->start_controls_section(
			'cta_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'shape_image',
                [
                    'label' => __( 'Shape Images', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'startnext-toolkit' ),
                    'label_off' => __( 'Hide', 'startnext-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->add_control(
                'background_color',
                [
                    'label' => __( 'Background Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .repair-cta-area.bg-0f054b, .iot-cta-area.bg-0f054b' => 'background-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .cta-repair-content h3, .cta-iot-content h3' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 10,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .cta-repair-content h3, .cta-iot-content h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
            $this->add_control(
                'description_color',
                [
                    'label' => __( 'Description Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .cta-repair-content p, .cta-iot-content p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'description_size',
                [
                    'label' => __( 'Description Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 10,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .cta-repair-content p, .cta-iot-content p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'button_color',
                [
                    'label' => __( 'Button Background Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .repair-cta-area .btn-primary, .iot-cta-area .btn-primary'  => 'background-color: {{VALUE}}',
                    ],
                ]
            );
    
            $this->add_control(
                'button_hover_color',
                [
                    'label' => __( 'Button Hover Background Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .repair-cta-area .btn::after, .btn::before, .iot-cta-area .btn::after, .btn::before' => 'background: {{VALUE}}',
                    ],
                ]
            );
    

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Inline Editing
        $this-> add_inline_editing_attributes('title','none');
        $this-> add_inline_editing_attributes('description','none');
        
        ?>
        <?php if( $settings['card_style'] == 3 ): ?>
            <div class="repair-cta-area bg-0f054b">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="cta-repair-content">
                                <h3 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h3>

                                <p <?php echo $this-> get_render_attribute_string('description'); ?>><?php echo esc_html( $settings['description'] ); ?></p>

                                <?php if( $settings['button_text'] ): ?>
                                    <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                                <?php endif; ?>
                                    
                            </div>
                        </div>
                        <div class="col-lg-6">
                                <div class="cta-repair-img">
                                    <?php if( $settings['image']['url'] != '' ): ?>
                                        <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>" class="wow fadeInUp" data-wow-delay="0.6s">
                                    <?php endif; ?>
                                </div>
                        </div>
                        
                    </div>
                </div>
                
                <?php if( $settings['shape_image'] == 'yes' ): ?>
                    <div class="circle-box"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/circle.png" alt="<?php echo esc_attr( $settings['title'] ); ?>"></div>
                    <div class="cta-shape"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/cta-shape.png" alt="<?php echo esc_attr( $settings['title'] ); ?>"></div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style'] == 2 ): ?>
            <div class="iot-cta-area bg-0f054b">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="cta-iot-img">
                                <?php if( $settings['image']['url'] != '' ): ?>
                                    <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>" class="wow fadeInUp" data-wow-delay="0.6s">
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="cta-iot-content">
                                <h3 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h3>

                                <p <?php echo $this-> get_render_attribute_string('description'); ?>><?php echo esc_html( $settings['description'] ); ?></p>

                                <?php if( $settings['button_text'] ): ?>
                                    <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                    </div>
                </div>
                
                <?php if( $settings['shape_image'] == 'yes' ): ?>
                    <div class="circle-box"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/circle.png" alt="<?php echo esc_attr( $settings['title'] ); ?>"></div>
                    <div class="cta-shape"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/cta-shape.png" alt="<?php echo esc_attr( $settings['title'] ); ?>"></div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_CTA );



?>

