<?php
/**
 * Faq Widget
 */

namespace Elementor;
class StartNext_Faq extends Widget_Base {

	public function get_name() {
        return 'StartNext_FAQ';
    }

	public function get_title() {
        return __( 'FAQ', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-accordion';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'startnext_faq',
			[
				'label' => __( 'Faq Control', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
		
		$this->add_control(
            'faq_item',
            [
                'label' => esc_html__('Faq Item', 'startnext-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'separator' => 'before',
                'fields' => [
					[	
						'name'	=> 'title',
						'label' => __( 'Title', 'startnext-toolkit' ),
						'type' => Controls_Manager::TEXT,
						'default' => __( 'How do permissions work in Google Play Instant?', 'startnext-toolkit' ),
					],

                    [
						'name'	=> 'content',
						'label' => __( 'Description', 'startnext-toolkit' ),
						'type' => Controls_Manager::TEXTAREA,
						'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. incididunt ut labore et dolore magna aliqua.', 'startnext-toolkit' ),
					],
                ],
            ]
        );
       
        $this->end_controls_section();

        $this->start_controls_section(
			'partner_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'active_color',
			[
				'label' => __( 'Active Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-accordion .accordion .accordion-item .accordion-title:hover, .faq-accordion .accordion .accordion-item .accordion-title.active' => 'background-color: {{VALUE}}',
				],
			]
        );

        $this->add_control(
			'title_bg',
			[
				'label' => __( 'Title Background Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ..faq-accordion .accordion .accordion-item .accordion-title' => 'background: {{VALUE}}',
				],
			]
        );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();
        $faq_item = $settings['faq_item'];
        $i = 0;
        ?>
        <div class="faq-accordion">
            <ul class="accordion">
                <?php 
                foreach ( $faq_item as $key => $value ): 
                    if( $i == 0 ) {
                        $active_class   = 'active';
                        $show_class     = 'show';
                    }else {
                        $active_class   = '';
                        $show_class     = '';
                    } 
                ?>
                    <li class="accordion-item">
                        <a class="accordion-title <?php echo esc_attr(  $active_class );?>" href="javascript:void(0)"><i class="flaticon-add"></i> <?php echo esc_html( $value['title'] ); ?></a>
                        <p class="accordion-content <?php echo esc_attr(  $show_class );?>"><?php echo esc_html( $value['content'] ); ?></p>
                    </li>
                    <?php $i ++; ?>
                <?php endforeach; ?>
            </ul>
        </div>
        
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Faq );
?>

