<?php
/**
 * Pricing Plan Widget
 */

namespace Elementor;
class StartNext_Pricing extends Widget_Base {

	public function get_name() {
        return 'Pricing';
    }

	public function get_title() {
        return __( 'Pricing', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-price-table';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'pricing_section',
			[
				'label' => __( 'Pricing Control', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Choose Style', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( 'Style One', 'startnext-toolkit' ),
                        2   => __( 'Style Two', 'startnext-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );
            $this->add_control(
                'icon',
                [
                    'label' => __( 'Icon', 'startnext-toolkit' ),
                    'type' => Controls_Manager::ICON,
                    'condition' => [
                        'card_style' => '2',
                    ],
                ]
            );
            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Basic Plan', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'currency',
                [
                    'label' => __( 'Currency ', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('$', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'price',
                [
                    'label' => __( 'Price', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('15.00', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'period',
                [
                    'label' => __( 'Period', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('/Mon', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Select Plan', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'button_link',
                [
                    'label' => __( 'Button Link', 'startnext-toolkit' ),
                    'type' => Controls_Manager::URL,
                ]
            );
            $this->add_control(
                'card_active',
                [
                    'label'         => __( 'Card Active?', 'startnext-toolkit' ),
                    'type'          => Controls_Manager::SWITCHER,
                    'label_on'      => __( 'Yes', 'startnext-toolkit' ),
                    'label_off'     => __( 'No', 'startnext-toolkit' ),
                    'return_value'  => 'yes',
                    'default'       => 'yes',
                ]
            );

            $this->add_control(
                'features',
                [
                    'type'    => Controls_Manager::REPEATER,
                    'label'   => esc_html__( 'Add new feature', 'startnext-toolkit' ),			                 
                    'fields'  => array(					
                        array(
                            'type'    => Controls_Manager::TEXT,
                            'name'    => 'feature_title',
                            'label'   => esc_html__( 'Feature Title', 'startnext-toolkit' ),
                            'default' => __('5 GB Bandwidth', 'startnext-toolkit'),
                        ),
                        array(
                            'name'          => 'disable_feature',
                            'label'         => __( 'Disable this Feature?', 'startnext-toolkit' ),
                            'type'          => Controls_Manager::SWITCHER,
                            'label_on'      => __( 'Enable', 'startnext-toolkit' ),
                            'label_off'     => __( 'Disable', 'startnext-toolkit' ),
                            'return_value'  => 'yes',
                            'default'       => 'no',
                        ),
                    ),	
                ]			
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'pricing_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'color',
                [
                    'label' => __( 'Main Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .pricing-table .price span' => 'color: {{VALUE}}',
                        '{{WRAPPER}} .pricing-table .pricing-header::before' => 'background: {{VALUE}}',
                        '{{WRAPPER}} .pricing-table .btn-primary' => 'background-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'button_hover_color',
                [
                    'label' => __( 'Button Hover Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} pricing-table.active-plan .btn-primary' => 'background: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .pricing-table .pricing-header h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        $this-> add_inline_editing_attributes('title','none');
        ?>
            <?php if($settings['card_style'] == 1 ):?>
                <div class="pricing-table <?php if( $settings['card_active'] == 'yes' ): echo esc_attr__( 'active-plan', 'startnext-toolkit' ); endif; ?>">
                    <div class="pricing-header">
                        <h3 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h3>
                    </div>
                    
                    <div class="price">
                        <span><sup><?php echo esc_html( $settings['currency'] ); ?></sup><?php echo esc_html( $settings['price'] ); ?> <span><?php echo esc_html( $settings['period'] ); ?></span></span>
                    </div>
                    
                    <div class="pricing-features">
                        <ul>
                            <?php foreach( $settings['features'] as $item ): ?>
                                <?php if( $item['disable_feature'] == 'yes' ): ?>
                                    <li><?php echo esc_html($item['feature_title']); ?></li>
                                <?php else: ?>
                                    <li class="active"><?php echo esc_html($item['feature_title']); ?></li>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    
                    <?php if( $settings['button_text'] != '' ): ?>
                        <div class="pricing-footer">
                            <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if($settings['card_style'] == 2 ):?>
                <div class="single-pricing-table ">
                    <div class="pricing-header">
                        <i class="<?php echo esc_attr( $settings['icon'] );?>"></i>
                        <h3 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h3>
                    </div>
                    
                    <div class="price">
                        <span><sup><?php echo esc_html( $settings['currency'] ); ?></sup><?php echo esc_html( $settings['price'] ); ?> <span><?php echo esc_html( $settings['period'] ); ?></span></span>
                    </div>
                    
                    <div class="pricing-features">
                        <ul>
                            <?php foreach( $settings['features'] as $item ): ?>
                                <?php if( $item['disable_feature'] == 'yes' ): ?>
                                    <li><?php echo esc_html($item['feature_title']); ?></li>
                                <?php else: ?>
                                    <li><i data-feather="check"></i> <?php echo esc_html($item['feature_title']); ?></li>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php if( $settings['button_text'] != '' ): ?>
                        <div class="pricing-footer">
                            <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Pricing );
?>

