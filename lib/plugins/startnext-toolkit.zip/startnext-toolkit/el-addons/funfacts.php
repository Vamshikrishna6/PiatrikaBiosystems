<?php
/**
 * Fun-Facts Widget
 */

namespace Elementor;
class StartNext_FunFacts extends Widget_Base {

	public function get_name() {
        return 'FunFacts';
    }

	public function get_title() {
        return __( 'FunFacts', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-counter';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_FunFacts',
			[
				'label' => __( 'FunFacts Control', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'count',
                [
                    'label' => __( 'Ending Number', 'startnext-toolkit' ),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 180,
                ]
            );

            $this->add_control(
                'number_prefix',
                [
                    'label' => __( 'Number Prefix', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                ]
            );

            $this->add_control(
                'number_suffix',
                [
                    'label' => __( 'Number Suffix', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('K', 'startnext-toolkit'),
                ]
            );

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Downloaded', 'startnext-toolkit'),
                ]
            );
       
        $this->end_controls_section();

        $this->start_controls_section(
			'style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_responsive_control(
                'number_font_size',
                [
                    'label' => __( 'Number Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .funfact h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
            
            $this->add_control(
                'number_color',
                [
                    'label' => __( 'Number Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .funfact h3' => 'color: {{VALUE}}',
                    ],
                ]
            );
            
            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .funfact p' => 'color: {{VALUE}}',
                    ],
                ]
            );
            
            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 30,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .funfact p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();
        ?>
            <div class="funfact">
                <h3><?php echo esc_html( $settings['number_prefix'] ); ?><span class="odometer" data-count="<?php echo esc_attr( $settings['count'] ); ?>">00</span><?php echo esc_html( $settings['number_suffix'] ); ?></h3>
                <p><?php echo esc_html( $settings['title'] ); ?></p>
            </div>
        <?php
	}
	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_FunFacts );
?>

