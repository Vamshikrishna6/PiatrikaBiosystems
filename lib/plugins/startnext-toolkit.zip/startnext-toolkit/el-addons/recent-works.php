<?php
/**
 * Recent Work Widget
 */

namespace Elementor;
class StartNext_Recent_Work extends Widget_Base {

	public function get_name() {
        return 'Recent_Work';
    }

	public function get_title() {
        return __( 'Projects', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-rating';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'recent_work_section',
			[
				'label' => __( 'Projects Control', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Choose Style', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( 'With Slider', 'startnext-toolkit' ),
                        2   => __( 'Without Slider', 'startnext-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );

            $this->add_control(
                'columns',
                [
                    'label' => __( 'Choose Columns', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( '2', 'startnext-toolkit' ),
                        3   => __( '3', 'startnext-toolkit' ),
                        4   => __( '4', 'startnext-toolkit' ),
                    ],
                    'default' => 4,
                    'condition' => [
                        'card_style' => '2'
                    ]
                ]
            );

            $this->add_control(
                'order',
                [
                    'label' => __( 'Project Order By', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'DESC'      => __( 'DESC', 'startnext-toolkit' ),
                        'ASC'       => __( 'ASC', 'startnext-toolkit' ),
                    ],
                    'default' => 'DESC',
                ]
            );

            $this->add_control(
                'count',
                [
                    'label' => __( 'Post Per Page', 'startnext-toolkit' ),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 4,
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'project_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-works .works-content h3 a' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-works .works-content h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Content Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-works .works-content p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'content_size',
                [
                    'label' => __( 'Content Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 30,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-works .works-content p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'hover_color',
                [
                    'label' => __( 'Card Hover Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-works::before' => 'background: {{VALUE}}',
                    ],
                ]
            );

        $this->end_controls_section();


    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Card Columns
        $columns = $settings['columns'];
        if ($columns == 2) {
            $column = 'col-lg-6 col-md-6';
        }elseif ($columns == 3) {
            $column = 'col-lg-4 col-md-6';
        }elseif ($columns == 4) {
            $column = 'col-lg-3 col-md-6';
        }
        
        // Project Query
        $args = array(
            'post_type'         => 'project',
            'posts_per_page'    => $settings['count'],
            'order'             => $settings['order']
        );

        $projects_array = new \WP_Query( $args ); 
        ?>

        <?php if( $settings['card_style']  == 1 ): ?>
            <div class="row m-0">
                <div class="works-slides">
                    <?php
                    while($projects_array->have_posts()): 
                        $projects_array->the_post();

                        // ACF Fields
                        $icon = get_field('project_icon');
                        ?>
                        <div class="col-lg-12">
                            <div class="single-works">
                            <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'project-card-thumb')); ?>" alt="<?php the_title(); ?>">
                                <a href="<?php the_permalink(); ?>" class="icon">
                                <i class="<?php echo esc_attr( $icon ); ?>"></i>
                                </a>
                                <div class="works-content">
                                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                    <p><?php the_excerpt(); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 2 ): ?>
            <div class="works-area ptb-80">
                <div class="row">
                    <?php
                    while($projects_array->have_posts()): 
                        $projects_array->the_post();
                        // ACF Fields
                        $icon = get_field('project_icon');
                        ?>
                        <div class="<?php echo esc_attr( $column ); ?>">
                            <div class="single-works">
                                <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'project-card-thumb')); ?>" alt="<?php the_title(); ?>">
                                <a href="<?php the_permalink(); ?>" class="icon">
                                    <i class="<?php echo esc_attr( $icon ); ?>"></i>
                                </a>
                                <div class="works-content">
                                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                    <p><?php the_excerpt(); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Recent_Work );
?>

