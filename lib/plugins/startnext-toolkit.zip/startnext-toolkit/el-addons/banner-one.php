<?php
/**
 * Banner One Widget
 */

namespace Elementor;
class StartNext_Banner_One extends Widget_Base {

	public function get_name() {
        return 'StartNext_Banner_One';
    }

	public function get_title() {
        return __( 'Banner', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-banner';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_Banner_One_Area',
			[
				'label' => __( 'StartNext Banner Controls', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
            'card_style',
            [
                'label' => __( 'Choose Style', 'startnext-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    1   => __( 'Style - 1', 'startnext-toolkit' ),
                    2   => __( 'Style - 2', 'startnext-toolkit' ),
                    3   => __( 'Style - 3', 'startnext-toolkit' ),
                    4   => __( 'Style - 4', 'startnext-toolkit' ),
                ],
                'default' => 1,
            ]
        );

        $this->add_control(
			'image',
			[
				'label' => __( 'Choose Banner Image', 'startnext-toolkit' ),
				'type' => Controls_Manager::MEDIA,
			]
        );

        $this->add_control(
			'image_bg',
			[
				'label' => __( 'Choose Banner Image(Background)', 'startnext-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'card_style' => '2',
                ]
			]
        );

        $this->add_control(
            'image_shape',
            [
                'label' => __( 'Remove Background Shape Images?', 'startnext-toolkit' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'startnext-toolkit' ),
                'label_off' => __( 'No', 'startnext-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'card_style' => ['3', '2'],
                ]
            ]
        );

        $this->add_control(
            'top_title',
            [
                'label' => __( 'Top Title', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Internet of Things', 'startnext-toolkit'),
                'condition' => [
                    'card_style' => '2',
                ]
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Secure IT Solutions for a more secure environment', 'startnext-toolkit'),
            ]
        );

        $this->add_control(
            'content',
            [
                'label' => __( 'Content', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.', 'startnext-toolkit'),
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __( 'Button Text', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Get Started', 'startnext-toolkit'),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => __( 'Button Link', 'startnext-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'name_label',
            [
                'label' => __( 'Name Label', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Full Name', 'startnext-toolkit'),
                'condition' => [
                    'card_style' => '4',
                ]
            ]
        );

        $this->add_control(
            'name_placeholder',
            [
                'label' => __( 'Name Placeholder', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Enter full name', 'startnext-toolkit'),
                'condition' => [
                    'card_style' => '4',
                ]
            ]
        );

        $this->add_control(
            'email_label',
            [
                'label' => __( 'Email Label', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Email', 'startnext-toolkit'),
                'condition' => [
                    'card_style' => '4',
                ]
            ]
        );

        $this->add_control(
            'email_placeholder',
            [
                'label' => __( 'Email Placeholder', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Enter your email', 'startnext-toolkit'),
                'condition' => [
                    'card_style' => '4',
                ]
            ]
        );

        $this->add_control(
            'sub_button',
            [
                'label' => __( 'Subscribe Button Text', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Subscribe Now', 'startnext-toolkit'),
                'condition' => [
                    'card_style' => '4',
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'banner_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'show_shape',
			[
				'label' => __( 'Shape Images', 'startnext-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'startnext-toolkit' ),
				'label_off' => __( 'Hide', 'startnext-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'top_title_color',
			[
				'label' => __( 'Top Title Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .iot-banner-content span' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'card_style' => '2',
                ]
			]
        );

        $this->add_responsive_control(
			'top_title_size',
			[
				'label' => __( 'Top Title Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 70,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .iot-banner-content span' => 'font-size: {{SIZE}}px;',
                ],
                'condition' => [
                    'card_style' => '2',
                ]
			]
        );
        
        $this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-banner .hero-content h1, .iot-banner-content h2' => 'color: {{VALUE}}',
				],
			]
        );

        $this->add_responsive_control(
			'title_size',
			[
				'label' => __( 'Title Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 70,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .main-banner .hero-content h1, .iot-banner-content h2' => 'font-size: {{SIZE}}px;',
				],
			]
		);
        
        $this->add_control(
			'content_color',
			[
				'label' => __( 'Content Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-banner .hero-content p, .iot-banner-content p' => 'color: {{VALUE}}',
				],
			]
        );
        
        $this->add_responsive_control(
			'content_size',
			[
				'label' => __( 'Content Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 50,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .main-banner .hero-content p, .iot-banner-content p' => 'font-size: {{SIZE}}px;',
				],
			]
        );

        $this->add_control(
			'button_color',
			[
				'label' => __( 'Button Background Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-banner .hero-content .btn-primary, .iot-banner-content .btn-primary' => 'background-color: {{VALUE}}',
				],
			]
        );

        $this->add_control(
			'button_hover_color',
			[
				'label' => __( 'Button Hover Background Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .main-banner .hero-content .btn::after, .btn::before, .iot-banner-content .btn::after, .btn::before' => 'background: {{VALUE}}',
				],
			]
        );

        $this->add_responsive_control(
			'button_size',
			[
				'label' => __( 'Button Text Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 20,
						'step' => 1,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .main-banner .btn, .iot-banner-content .btn' => 'font-size: {{SIZE}}px;',
				],
			]
		);

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Inline Editing
        $this-> add_inline_editing_attributes('top_title','none');
        $this-> add_inline_editing_attributes('title','none');
        $this-> add_inline_editing_attributes('content','none');
        
        ?>
        <?php if( $settings['card_style'] == 1 ): ?>
            <div class="main-banner">
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="container">
                            <div class="row h-100 justify-content-center align-items-center">
                                <div class="col-lg-5">
                                    <div class="hero-content">
                                        <h1 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h1>
                                        <p <?php echo $this-> get_render_attribute_string('content'); ?>><?php echo esc_html( $settings['content'] ); ?></p>

                                        <?php if( $settings['button_text'] != '' ): ?>
                                            <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-lg-6 offset-lg-1">
                                    <div class="banner-image">
                                        <?php if( $settings['image']['url'] == '' ): ?>
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/man.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="<?php echo esc_attr__('man','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/code.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr__('code','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/carpet.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="<?php echo esc_attr__('carpet','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/bin.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr__('bin','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/book.png" class="wow bounceIn" data-wow-delay="0.6s" alt="<?php echo esc_attr__('book','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/dekstop.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="<?php echo esc_attr__('dekstop','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/dot.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr__('dot','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/flower-top-big.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr__('flower-top-big','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/flower-top.png" class="wow rotateIn" data-wow-delay="0.6s" alt="<?php echo esc_attr__('flower-top','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/keyboard.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr__('keyboard','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/pen.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr__('pen','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/table.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr__('table','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/tea-cup.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="<?php echo esc_attr__('tea-cup','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/headphone.png" class="wow rollIn" data-wow-delay="0.6s" alt="<?php echo esc_attr__('headphone','startnext-toolkit'); ?>">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/banner-image/main-pic.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr__('main-pic','startnext-toolkit'); ?>">
                                        <?php else: ?>
                                            <img src="<?php esc_url( $settings['image']['url'] ); ?>" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr($settings['title']); ?>">
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if( $settings['show_shape'] == 'yes' ): ?>
                    <div class="shape1"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape1.png" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape2 rotateme"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape2.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape3"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape3.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape4"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape5"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape5.png" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape6 rotateme"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape7"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape8 rotateme"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape2.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                <?php endif; ?>
            </div>
        <?php elseif( $settings['card_style'] == 3 ): ?>
            <div class="repair-main-banner">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="repair-banner-content">
                                <h1 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h1>
                                <p <?php echo $this-> get_render_attribute_string('content'); ?>><?php echo esc_html( $settings['content'] ); ?></p>

                                <?php if( $settings['button_text'] != '' ): ?>
                                    <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="repair-banner-image">
                                <?php if( $settings['image']['url'] != '' ): ?>
                                    <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>" class="wow fadeInUp" data-wow-delay="0.8s" >
                                <?php endif; ?>

                                <?php if( $settings['image_shape'] == 'yes' ): ?>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/repair-banner-image/1.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr($settings['title']); ?>">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/repair-banner-image/2.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="<?php echo esc_attr($settings['title']); ?>">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/repair-banner-image/circle.png" class="rotateme" alt="<?php echo esc_attr($settings['title']); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif( $settings['card_style'] == 2 ): ?>
            <div class="iot-main-banner">
                <div class="container">
                    <div class="iot-banner-content">
                        <span <?php echo $this-> get_render_attribute_string('top_title'); ?>><?php echo esc_html( $settings['top_title'] ); ?></span>
                        <h2 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h1>
                        <p <?php echo $this-> get_render_attribute_string('content'); ?>><?php echo esc_html( $settings['content'] ); ?></p>
                        <?php if( $settings['button_text'] != '' ): ?>
                            <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                        <?php endif; ?>
                    </div>

                    <div class="iot-banner-image">
                        <?php if( $settings['image']['url'] != '' ): ?>
                            <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>" class="wow fadeInUp" data-wow-delay="0.8s">
                        <?php endif; ?>

                        <?php if( $settings['image_bg']['url'] != '' ): ?>
                            <img src="<?php echo esc_url( $settings['image_bg']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>" class="wow zoomIn" data-wow-delay="0.8s" >
                        <?php endif; ?>
                    </div>

                    <?php if( $settings['image_shape'] == 'yes' ): ?>
                        <div class="animate-border">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php elseif( $settings['card_style'] == 4 ): ?>
            <div class="main-banner">
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="container">
                            <div class="row h-100 justify-content-center align-items-center">
                                <div class="col-lg-5">
                                    <div class="hero-content">
                                        <h1 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h1>
                                        <p <?php echo $this-> get_render_attribute_string('content'); ?>><?php echo esc_html( $settings['content'] ); ?></p>

                                        <?php if( $settings['button_text'] != '' ): ?>
                                            <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-lg-5 offset-lg-1">
                                    <div class="banner-form ml-3">
                                        <form class="newsletter-form" method="post" action="<?php bloginfo('name'); ?>/?na=s" onsubmit="return newsletter_check(this)">
                                            <div class="form-group">
                                                <label><?php echo esc_html( $settings['name_label'] ); ?></label>
                                                <input type="text" name="nn" class="form-control" placeholder="<?php echo esc_attr( $settings['name_placeholder'] ); ?>">
                                            </div>
                                            <div class="form-group">
                                                <label><?php echo esc_html( $settings['email_label'] ); ?></label>
                                                <input type="email" name="ne" class="form-control" placeholder="<?php echo esc_attr( $settings['email_placeholder'] ); ?>">
                                            </div>
                                            <button type="submit" class="btn btn-primary"><?php echo esc_html( $settings['sub_button'] ); ?></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if( $settings['show_shape'] == 'yes' ): ?>
                    <div class="shape1"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape1.png" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape2 rotateme"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape2.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape3"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape3.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape4"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape5"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape5.png" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape6 rotateme"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape7"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                    <div class="shape8 rotateme"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape2.svg" alt="<?php echo esc_attr__('shape','startnext-toolkit'); ?>"></div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Banner_One );
?>

