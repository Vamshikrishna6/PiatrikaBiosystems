<?php
/**
 * Hosting Widget
 */

namespace Elementor;
class StartNext_Hosting_Banner extends Widget_Base {

	public function get_name() {
        return 'StartNext_Hosting_Banner';
    }

	public function get_title() {
        return __( 'Hosting Banner', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-banner';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_Hosting_Banner_Area',
			[
				'label' => __( 'StartNext Hosting Banner Controls', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'image',
			[
				'label' => __( 'Choose Banner Image', 'startnext-toolkit' ),
				'type' => Controls_Manager::MEDIA,
			]
        );

        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('The Best Web Hosting', 'startnext-toolkit'),
            ]
        );

        $this->add_control(
            'content',
            [
                'label' => __( 'Content', 'startnext-toolkit' ),
                'type' => Controls_Manager::WYSIWYG,
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __( 'Button Text', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Get Started', 'startnext-toolkit'),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => __( 'Button Link', 'startnext-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'banner_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'show_shape',
			[
				'label' => __( 'Shape Images', 'startnext-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'startnext-toolkit' ),
				'label_off' => __( 'Hide', 'startnext-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'banner_background',
			[
				'label' => __( 'Background Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hosting-main-banner' => 'background-color: {{VALUE}}',
				],
			]
        );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Inline Editing
        $this-> add_inline_editing_attributes('title','none');
        $this-> add_inline_editing_attributes('content','none');
        
        ?>

        <div class="hosting-main-banner ">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6 col-md-12">
                                <div class="hosting-banner-content">
                                    <h1 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h1>
                                    <?php echo $settings['content'] ?>

                                    <?php if( $settings['button_text'] != '' ): ?>
                                        <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-12">
                                <div class="hosting-banner-image">
                                    <?php if( $settings['image']['url'] == '' ): ?>
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hosting-banner-image/1.png" class="wow fadeInDown" data-wow-delay="0.7s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hosting-banner-image/2.png" class="wow fadeInDown" data-wow-delay="0.7s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hosting-banner-image/3.png" class="wow fadeInDown" data-wow-delay="0.7s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hosting-banner-image/4.png" class="wow fadeInDown" data-wow-delay="0.7s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hosting-banner-image/5.png" class="wow fadeInDown" data-wow-delay="0.7s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hosting-banner-image/6.png" class="wow fadeInDown" data-wow-delay="0.7s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hosting-banner-image/7.png" class="wow fadeInDown" data-wow-delay="0.7s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hosting-banner-image/8.png" class="wow fadeInDown" data-wow-delay="0.7s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hosting-banner-image/9.png" class="wow fadeInDown" data-wow-delay="0.7s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/hosting-banner-image/static-main.png" class="wow fadeInDown" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] );?>" class="wow fadeInDown bannerrightimg" >
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if($settings['show_shape'] == 'yes' ): ?>
                <div class="shape1">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape1.png" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                </div>
                <div class="shape2 rotateme">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape2.svg" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                </div>
                <div class="shape3">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape3.svg" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                </div>
                <div class="shape4">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                </div>
                <div class="shape5">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape5.png" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                </div>
                <div class="shape6 rotateme">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                </div>
                <div class="shape7">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                </div>
                <div class="shape8 rotateme">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape2.svg" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                </div>
            <?php endif; ?>
        </div>
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Hosting_Banner );
?>

