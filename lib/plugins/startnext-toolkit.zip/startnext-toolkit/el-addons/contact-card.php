<?php
/**
 * Contact Widget
 */

namespace Elementor;
class StartNext_Contact_Card extends Widget_Base {

	public function get_name() {
        return 'Contact_Card';
    }

	public function get_title() {
        return __( 'Contact Card', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-tel-field';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_Contact_Card',
			[
				'label' => __( 'Contact Card', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
            'icon',
            [
                'label' => __( 'Icons', 'startnext-toolkit' ),
                'type' => Controls_Manager::ICON,
            ]

        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'startnext-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Phone / Fax', 'startnext-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'content',
            [
                'label' => __( 'Content', 'startnext-toolkit' ),
                'type' => Controls_Manager::WYSIWYG,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'card_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
		
        $this->add_control(
			'color',
			[
				'label' => __( 'Card Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .contact-info-box .icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .contact-info-box:hover .icon' => 'background-color: {{VALUE}}',
				],
			]
        );
        $this->add_control(
			'color_hover_color',
			[
				'label' => __( 'Icon Color on Hover', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .contact-info-box:hover .icon' => 'color: {{VALUE}}',
				],
			]
        );

        $this->add_responsive_control(
			'cc_icon_size',
			[
				'label' => __( 'Card Icon Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 5,
						'max' => 70,
						'step' => 1,
					],
				],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .contact-info-box .icon' => 'font-size: {{SIZE}}px;',
				],
			]
		);
        
        $this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .contact-info-box h3' => 'color: {{VALUE}}',
				],
			]
        );
        
        $this->add_responsive_control(
			'title_size',
			[
				'label' => __( 'Title Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 40,
						'step' => 1,
					],
				],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}}  .contact-info-box h3' => 'font-size: {{SIZE}}px;',
				],
			]
        );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();
        ?>
        
            <div class="contact-info-box">
                <div class="icon">
                    <i class="<?php echo esc_attr( $settings['icon'] ); ?>"></i>
                </div>
                <h3><?php echo esc_html( $settings['title'] ); ?></h3>
                <?php echo ( wp_kses_post( $settings['content'] ) ); ?>
            </div>

        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Contact_Card );
?>

