<?php
/**
 * Team Widget
 */
namespace Elementor;
class StartNext_Team extends Widget_Base{
    public function get_name(){
        return "StartNext_Team";
    }
    public function get_title(){
        return "Team";
    }
    public function get_icon(){
        return "eicon-gallery-group";
    }
    public function get_categories(){
        return ['startnext-elements'];
    }
    protected function _register_controls(){

    $this->start_controls_section(
        'StartNext_Team',
        [
            'label' => __( 'StartNext Team', 'startnext-toolkit' ),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]
    );

        $this->add_control(
            'choose_type',
            [
                'label' => esc_html__( 'Choose Style', 'tryo-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    1   => esc_html__( 'Style Slider', 'tryo-toolkit' ),
                    2   => esc_html__( 'Style Card', 'tryo-toolkit' ),
                ], 
                'default' => 1,
            ]
        );

        $this->add_control(
            'columns',
            [
                'label' => __( 'Choose Columns', 'startnext-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    1   => __( '1', 'startnext-toolkit' ),
                    2   => __( '2', 'startnext-toolkit' ),
                    3   => __( '3', 'startnext-toolkit' ),
                    4   => __( '4', 'startnext-toolkit' ),
                ],
                'default' => 4,
                'condition' => [
                    'choose_type' => '2'
                ]
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'member_img', 
            [
                'label' => esc_html__( 'Image', 'tryo-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'name',
            [
                'label' => esc_html__( 'Member Name', 'tryo-toolkit' ),
                'type' => Controls_Manager::TEXT,
            ]
        );
        $repeater->add_control(
            'designation',
            [
                'label' => esc_html__( 'Designation', 'tryo-toolkit' ),
                'type' => Controls_Manager::TEXT,
            ]
        );
        $repeater->add_control(
            'desc',
            [
                'label' => esc_html__( 'Description', 'tryo-toolkit' ),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );
        $repeater->add_control(
            'icon1',
            [
                'label' => esc_html__( 'Social Icon One', 'tryo-toolkit' ),
                'type' => Controls_Manager::ICON,
            ]
        );
        $repeater->add_control(
            'url1',
            [
                'label' => esc_html__( 'Social Link One', 'tryo-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'icon2',
            [
                'label' => esc_html__( 'Social Icon Two', 'tryo-toolkit' ),
                'type' => Controls_Manager::ICON,
            ]
        );
        $repeater->add_control(
            'url2',
            [
                'label' => esc_html__( 'Social Link Two', 'tryo-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'icon3',
            [
                'label' => esc_html__( 'Social Icon Three', 'tryo-toolkit' ),
                'type' => Controls_Manager::ICON,
            ]
        );
        $repeater->add_control(
            'url3',
            [
                'label' => esc_html__( 'Social Link Three', 'tryo-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'icon4',
            [
                'label' => esc_html__( 'Social Icon Four', 'tryo-toolkit' ),
                'type' => Controls_Manager::ICON,
            ]
        );
        $repeater->add_control(
            'url4',
            [
                'label' => esc_html__( 'Social Link Four', 'tryo-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'icon5',
            [
                'label' => esc_html__( 'Social Icon Five', 'tryo-toolkit' ),
                'type' => Controls_Manager::ICON,
            ]
        );
        $repeater->add_control(
            'url5',
            [
                'label' => esc_html__( 'Social Link Five', 'tryo-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'teams',
            [
                'label' => esc_html__( 'Add Member', 'tryo-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );
    $this-> end_controls_section();

    // Start Style content controls
    $this-> start_controls_section(
        'style',
        [
            'label'=>esc_html__('Style', 'tryo-toolkit'),
            'tab'=> Controls_Manager::TAB_STYLE,
        ]
    );

        $this->add_control(
            'name_color',
            [
                'label' => esc_html__( 'Member Name Color', 'tryo-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-team .team-info h3' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'name_size',
            [
                'label' => esc_html__( 'Member Name Font Size', 'tryo-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .single-team .team-info h3' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'designation_color',
            [
                'label' => esc_html__( 'Member Designation Color', 'tryo-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-team .team-info span' => 'color: {{VALUE}}',
                ],
            ]
        );
    $this->add_responsive_control(
        'designation_size',
        [
            'label' => esc_html__( 'Member Designation Font Size', 'tryo-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 20,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-team .team-info span' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    $this-> end_controls_section(); 
}
    protected function render() 
    {
        $settings = $this->get_settings_for_display(); 

        // Card Columns
        $columns = $settings['columns'];
        if ($columns == 1) {
            $column = 'col-lg-12 col-md-6';
        }elseif ($columns == 2) {
            $column = 'col-lg-6 col-md-6';
        }elseif ($columns == 3) {
            $column = 'col-lg-4 col-md-6';
        }elseif ($columns == 4) {
            $column = 'col-lg-3 col-md-6';
        }
        
        ?>

        <?php if( $settings['choose_type'] == 1 ): ?>
            <div class="row m-0">
                <div class="team-slider">
                    <?php if ( $settings['teams'] != '' ): ?>
                        <?php foreach( $settings['teams'] as $item ): ?>
                            <div class="col-lg-12">
                                <div class="single-team">
                                    <div class="team-image">
                                        <?php if( $item['member_img']['url'] != '' ): ?>
                                            <img src="<?php echo esc_url( $item['member_img']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" class="wow fadeInDown bannerrightimg" >
                                        <?php endif; ?>
                                    </div>

                                    <div class="team-content">
                                        <div class="team-info">
                                            <h3><?php echo esc_html( $item['name'] ); ?></h3>
                                            <span><?php echo esc_html( $item['designation'] ); ?></span>
                                        </div>

                                        <ul>
                                            <?php if( $item['icon1'] != '' && $item['url1']['url'] != '' ): ?>
                                                <li><a href="<?php echo esc_url( $item['url1']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon1'] ); ?>"></i></a></li>
                                            <?php endif; ?>

                                            <?php if( $item['icon2'] != '' && $item['url2']['url'] != '' ): ?>
                                                <li><a href="<?php echo esc_url( $item['url2']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon2'] ); ?>"></i></a></li>
                                            <?php endif; ?>

                                            <?php if( $item['icon3'] != '' && $item['url3']['url'] != '' ): ?>
                                                <li><a href="<?php echo esc_url( $item['url3']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon3'] ); ?>"></i></a></li>
                                            <?php endif; ?>

                                            <?php if( $item['icon4'] != '' && $item['url4']['url'] != '' ): ?>
                                                <li><a href="<?php echo esc_url( $item['url4']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon4'] ); ?>"></i></a></li>
                                            <?php endif; ?>
                                            <?php if( $item['icon5']
                                                != '' && $item['url5']['url'] != '' ): ?>
                                                <li><a href="<?php echo esc_url( $item['url5']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon5'] ); ?>"></i></a></li>
                                            <?php endif; ?>
                                        </ul>
                                        <p><?php echo esc_html( $item['desc'] ); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['choose_type'] == 2 ): ?>
            <div class="container">
                <div class="row">
                    <?php if ( $settings['teams'] != '' ): ?>
                        <?php foreach( $settings['teams'] as $item ): ?>
                            <div class="<?php echo esc_attr($column); ?>">
                                <div class="single-team">
                                    <div class="team-image">
                                        <img src="<?php echo esc_url( $item['member_img']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" class="wow fadeInDown bannerrightimg" >
                                    </div>

                                    <div class="team-content">
                                        <div class="team-info">
                                            <h3><?php echo esc_html( $item['name'] ); ?></h3>
                                            <span><?php echo esc_html( $item['designation'] ); ?></span>
                                        </div>
                                        <ul>
                                            <?php if( $item['icon1'] != '' && $item['url1']['url'] != '' ): ?>
                                                <li><a href="<?php echo esc_url( $item['url1']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon1'] ); ?>"></i></a></li>
                                            <?php endif; ?>

                                            <?php if( $item['icon2'] != '' && $item['url2']['url'] != '' ): ?>
                                                <li><a href="<?php echo esc_url( $item['url2']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon2'] ); ?>"></i></a></li>
                                            <?php endif; ?>

                                            <?php if( $item['icon3'] != '' && $item['url3']['url'] != '' ): ?>
                                                <li><a href="<?php echo esc_url( $item['url3']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon3'] ); ?>"></i></a></li>
                                            <?php endif; ?>

                                            <?php if( $item['icon4'] != '' && $item['url4']['url'] != '' ): ?>
                                                <li><a href="<?php echo esc_url( $item['url4']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon4'] ); ?>"></i></a></li>
                                            <?php endif; ?>
                                            <?php if( $item['icon5']
                                                != '' && $item['url5']['url'] != '' ): ?>
                                                <li><a href="<?php echo esc_url( $item['url5']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon5'] ); ?>"></i></a></li>
                                            <?php endif; ?>
                                        </ul>
                                        <p><?php echo esc_html( $item['desc'] ); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

    <?php    
    }

    protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Team );