<?php
/**
 * Features Box Slider Widget
 */

namespace Elementor;
class Features_Box_Slider extends Widget_Base {

	public function get_name() {
        return 'Features_Box';
    }

	public function get_title() {
        return __( 'Features Box Slider', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-star-o';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

            $this->add_control(
                'feature_item',
                [
                    'label' => esc_html__('Feature Item', 'startnext-toolkit'),
                    'type' => Controls_Manager::REPEATER,
                    'default' => [
                        [ 'name' => esc_html__(' Feature #1', 'startnext-toolkit') ],
            
                    ],
                    'fields' => [
                        [
                            'name'  => 'icon',
                            'label' => __( 'Icon', 'startnext-toolkit' ),
                            'type' => Controls_Manager::ICON,
                        ],
                        [
                            'name'  => 'icon_color',
                            'label' => __( 'Icon', 'startnext-toolkit' ),
                            'type' => Controls_Manager::COLOR,
                        ],

                        [
                            'name'  => 'icon_bg_color',
                            'label' => __( 'Icon Background Color', 'startnext-toolkit' ),
                            'type' => Controls_Manager::COLOR,
                        ],
                
                        [
                            'name' => 'title',
                            'label' => esc_html__('Title', 'startnext-toolkit'),
                            'type' => Controls_Manager::TEXT,
                            'default' => esc_html__('Professional Tools', 'startnext-toolkit'),
                            'label_block' => true,
                        ],
                        [
                            'name' => 'description',
                            'label' => esc_html__('Description', 'startnext-toolkit'),
                            'type' => Controls_Manager::TEXTAREA,
                            'default' => esc_html__('Lorem ipsum dolor sit amet elit, adipiscing, sed do eiusmod tempor incididunt ut labore dolore magna.', 'startnext-toolkit'),
                            'label_block' => true,
                        
                        ],
                    ],
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section(
			'box_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-box h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_responsive_control(
                'description_size',
                [
                    'label' => __( 'Description Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-box p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
           
        $this->end_controls_section();
    }

	protected function render() {

        $settings   = $this->get_settings_for_display();
        ?>
            <div class="row">
                <div class="boxes-slides">
                    <?php foreach( $settings['feature_item'] as $item ): ?>
                        <div class="col-lg-12 col-md-12">
                            <div class="single-box">
                                <div class="icon" style="background:<?php echo esc_attr($item['icon_bg_color']); ?>;">
                                    <i class="<?php echo esc_attr( $item['icon'] ); ?>" style="color:<?php echo esc_attr( $item['icon_color'] ); ?>"></i>
                                </div>
                                <h3><?php echo esc_html( $item['title'] ); ?></h3>
                                <p><?php echo esc_html( $item['description'] ); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php
	}
	protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new Features_Box_Slider );
?>

