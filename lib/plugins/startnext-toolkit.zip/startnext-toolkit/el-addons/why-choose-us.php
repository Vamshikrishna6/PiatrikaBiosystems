<?php
/**
 * Why Choose Us Widget
 */

namespace Elementor;
class StartNext_Why_Choose_Us extends Widget_Base {

	public function get_name() {
        return 'Why_Choose_Us';
    }

	public function get_title() {
        return __( 'Why Choose Us', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-alert';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_Why_Choose_Us',
			[
				'label' => __( 'Why Choose Us', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Why Choose Us', 'startnext-toolkit'),
                ]
            );

            $this->add_control(
                'title_shape',
                [
                    'label' => __( 'Show Title Shape', 'startnext-toolkit' ),
                    'type' =>Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'startnext-toolkit' ),
                    'label_off' => __( 'Hide', 'startnext-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->add_control(
                'content',
                [
                    'label' => __( 'Content', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'startnext-toolkit'),
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Choose Image', 'startnext-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );

            $this->add_control(
                'image_animation',
                [
                    'label' => __( 'Image Animation', 'startnext-toolkit' ),
                    'type' =>Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'startnext-toolkit' ),
                    'label_off' => __( 'Hide', 'startnext-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->add_control(
                'cards',
                [
                    'type'    => Controls_Manager::REPEATER,
                    'label'   => esc_html__( 'Add Card', 'startnext-toolkit' ),			                 
                    'fields'  => array(			
                        array(
                            'type'    => Controls_Manager::ICON,
                            'name'    => 'icon',
                            'label'   => esc_html__( 'Icon', 'startnext-toolkit' ),
                        ),		
                        array(
                            'type'    => Controls_Manager::TEXT,
                            'name'    => 'card_title',
                            'label'   => esc_html__( 'Title', 'startnext-toolkit' ),
                            'default' => __('Proficient & Friendly', 'startnext-toolkit'),
                        ),
                        array(
                            'type'    => Controls_Manager::TEXTAREA,
                            'name'    => 'card_desc',
                            'label'   => esc_html__( 'Description', 'startnext-toolkit' ),
                            'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.', 'startnext-toolkit'),
                        ),
                    ),	
                ]			
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'section_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
        
            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .why-choose-us .section-title h2' => 'color: {{VALUE}}',
                    ],
                ]
            );
        
            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 10,
                            'max' => 60,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .why-choose-us .section-title h2' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Content Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .why-choose-us .section-title p' => 'color: {{VALUE}}',
                    ],
                ]
            );
        
            $this->add_responsive_control(
                'content_size',
                [
                    'label' => __( 'Content Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 10,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .why-choose-us .section-title p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'icon_color',
                [
                    'label' => __( 'Card Icon Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-why-choose-us i' => 'color: {{VALUE}}',
                    ],
                ]
            );
        
            $this->add_responsive_control(
                'icon_size',
                [
                    'label' => __( 'Card Icon Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 90,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-why-choose-us .icon i::before' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'card_title_color',
                [
                    'label' => __( 'Card Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-why-choose-us h3' => 'color: {{VALUE}}',
                    ],
                ]
            );
        
            $this->add_responsive_control(
                'card_title_size',
                [
                    'label' => __( 'Card Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-why-choose-us h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'card_content_color',
                [
                    'label' => __( 'Card Content Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-why-choose-us p' => 'color: {{VALUE}}',
                    ],
                ]
            );
        
            $this->add_responsive_control(
                'card_content_size',
                [
                    'label' => __( 'Card Content Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-why-choose-us p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Inline Editing
        $this-> add_inline_editing_attributes('title','none');
        $this-> add_inline_editing_attributes('content','none');
        ?>

        <div class="why-choose-us ptb-80 ">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-12">
                        <div class="section-title">
                            <h2 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h2>
                    
                            <?php if( $settings['title_shape'] == 'yes' ): ?>
                                <div class="bar"></div>
                            <?php else: ?>
                                <br>
                            <?php endif; ?>

                            <p <?php echo $this-> get_render_attribute_string('content'); ?>><?php echo esc_html( $settings['content'] ); ?></p>
                        </div>

                        <?php if( $settings['image']['url'] == '' ): ?>  
                            <div class="why-choose-us-image">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/why-choose-us-image/man-stand.png" class="wow fadeInLeft" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/why-choose-us-image/database.png" class="wow fadeInRight" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php if( $settings['image_animation'] == 'yes' ): ?>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/cercle-shape.png" class="rotateme" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php else: ?>
                                    <img src="">
                                <?php endif; ?>

                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/why-choose-us-image/main-static.png" class="main-pic wow fadeInUp" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                            </div>
                        <?php else: ?>
                            <div class="why-choose-us-single-image">
                                <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php if( $settings['image_animation'] == 'yes' ): ?>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/cercle-shape.png" class="rotateme" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php else: ?>
                                    <img src="">
                                <?php endif; ?>.   
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-6 col-md-12">
                        <div class="row">

                            <?php foreach( $settings['cards'] as $item ): ?>
                                <div class="col-lg-6 col-md-6">
                                    <div class="single-why-choose-us">
                                        <div class="icon">
                                            <i class="<?php echo esc_attr($item['icon']); ?>"></i>
                                        </div>
                                        <h3><?php echo esc_html( $item['card_title'] ); ?></h3>
                                        <p><?php echo esc_html( $item['card_desc'] ); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Why_Choose_Us );
?>

