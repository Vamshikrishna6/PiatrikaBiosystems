<?php
/**
 * Partner Widget
 */

namespace Elementor;
class StratNext_Partner extends Widget_Base {

	public function get_name() {
        return 'StratNext_Partner';
    }

	public function get_title() {
        return __( 'Partner', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-logo';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StratNext_Partner',
			[
				'label' => __( 'Partner Control', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'startnext-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Ready To Talk?', 'startnext-toolkit'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'short_desc',
            [
                'label' => esc_html__('Short Description', 'startnext-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Our team is here to answer your question about startnext', 'startnext-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'left_button_text',
            [
				'label' => __( 'Left Button Text', 'startnext-toolkit' ),
				 
                'type' => Controls_Manager::TEXT,
                'default' => __('Contact Us', 'startnext-toolkit'),
            ]
        );

        $this->add_control(
            'left_button_link',
            [
                'label' => __( 'Left Button Link', 'startnext-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'right_button_text',
            [
				'label' => __( 'Right Button Text', 'startnext-toolkit' ),
				 
                'type' => Controls_Manager::TEXT,
                'default' => __('Or, get started now with a free trial', 'startnext-toolkit'),
            ]
        );

        $this->add_control(
            'right_button_link',
            [
                'label' => __( 'Right Button Link', 'startnext-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'desc',
            [
                'label' => esc_html__('Description', 'startnext-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('More that 1.5 million businesses and organizations use startnext', 'startnext-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'partner_item',
            [
                'label' => esc_html__('Partner Item', 'startnext-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'separator' => 'before',
                'fields' => [
					[	
						'name'	=> 'logo',
						'label' => __( 'Partner Logo', 'startnext-toolkit' ),
						'type' => Controls_Manager::MEDIA,
                    ],
                    
                    [	
						'name'	=> 'logo_hover',
						'label' => __( 'Hover Partner Logo', 'startnext-toolkit' ),
						'type' => Controls_Manager::MEDIA,
					],

                    [
						'name'	=> 'link',
						'label' => __( 'Link', 'startnext-toolkit' ),
						'type' => Controls_Manager::URL,
						'show_external' => true,
						'default' => [
							'url' => '#',
						],
					],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
			'ctt_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        
        $this->add_responsive_control(
			'title_size',
			[
				'label' => __( 'Title Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 70,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .ready-to-talk-content h3' => 'font-size: {{SIZE}}px;',
				],
			]
        );
        
        $this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ready-to-talk-content h3' => 'color: {{VALUE}}',
				],
			]
        );

        $this->add_responsive_control(
			'short_desc_size',
			[
				'label' => __( 'Short Description Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 40,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .ready-to-talk-content p' => 'font-size: {{SIZE}}px;',
				],
			]
        );
        
        $this->add_control(
			'short_desc_color',
			[
				'label' => __( 'Short Description Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ready-to-talk-content p' => 'color: {{VALUE}}',
				],
			]
        );

        $this->add_responsive_control(
			'desc_size',
			[
				'label' => __( 'Description Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 40,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .partner-area h5' => 'font-size: {{SIZE}}px;',
				],
			]
        );
        
        $this->add_control(
			'desc_color',
			[
				'label' => __( 'Description Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .partner-area h5' => 'color: {{VALUE}}',
				],
			]
        );

        $this->add_control(
            'show_partner',
            [
                'label' => __( 'Show Logo area', 'startnext' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'startnext' ),
                'label_off' => __( 'Hide', 'startnext' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_content',
            [
                'label' => __( 'Show content area', 'startnext' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'startnext' ),
                'label_off' => __( 'Hide', 'startnext' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Inline Editing
        $this-> add_inline_editing_attributes('title','none');
        $this-> add_inline_editing_attributes('short_desc','none');
        $this-> add_inline_editing_attributes('desc','none');
        ?>

        <!-- Start Ready To Talk Area -->
        <?php if( $settings['show_content'] == 'yes' ): ?>
            <div class="ready-to-talk">
                <div class="container">
                    <div class="ready-to-talk-content">
                        <h3 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h3>
                        <p <?php echo $this-> get_render_attribute_string('short_desc'); ?>><?php echo esc_html( $settings['short_desc'] ); ?></p>

                        <?php if( $settings['left_button_text'] != '' ): ?>
                            <a href="<?php echo esc_url( $settings['left_button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['left_button_text'] ); ?></a>
                        <?php endif; ?>
                        <span><a href="<?php echo esc_url( $settings['left_button_link']['url'] ); ?>"><?php echo esc_html( $settings['right_button_text'] ); ?></a></span>
                    </div>
                </div>
            </div> <!-- End Ready To Talk Area -->
        <?php endif; ?>
        
		<div class="partner-area partner-section"><!-- Start Partner Area -->
			<div class="container">
                <?php if( $settings['show_content'] == 'yes' ): ?>
                    <h5 <?php echo $this-> get_render_attribute_string('desc'); ?>><?php echo esc_html( $settings['desc'] ); ?></h5>
                <?php endif; ?>

                <?php if( $settings['show_partner'] == 'yes' ): ?>
                    <div class="partner-inner">
                        <div class="row">
                            <?php foreach( $settings['partner_item'] as $item ): ?>
                                <div class="col-lg-2 col-md-3 col-6">
                                    <?php if( $item['logo']['url'] != '' ): ?>
                                        <a href="<?php echo esc_url( $item['link']['url'] ); ?>">
                                            <img src="<?php echo esc_url( $item['logo']['url'] ); ?>" alt="<?php echo esc_attr__( 'Partner', 'startnext' ); ?>">
                                            <img src="<?php echo esc_url( $item['logo_hover']['url'] ); ?>" alt="<?php echo esc_attr__( 'Partner', 'startnext' ); ?>">
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
			</div>
		</div> <!-- End Partner Area -->
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StratNext_Partner );
?>

