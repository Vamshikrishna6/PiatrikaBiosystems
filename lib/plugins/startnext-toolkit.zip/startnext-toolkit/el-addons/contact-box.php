<?php
/**
 * Contact Box Widget
 */

namespace Elementor;
class StartNext_Contact_Box extends Widget_Base {

	public function get_name() {
        return 'Contact_Box';
    }

	public function get_title() {
        return __( 'ContactBox', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-tel-field';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_Contact_Box',
			[
				'label' => __( 'Contact Box Control', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Have any question about us?', 'startnext-toolkit'),
                ]
            );

            $this->add_control(
                'short_title',
                [
                    'label' => __( 'Short Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__("Don't hesitate to contact us", "startnext-toolkit"),
                ]
            );

            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Contact Us', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'button_link',
                [
                    'label' => __( 'Button Link', 'startnext-toolkit' ),
                    'type' => Controls_Manager::URL,
                ]
            );
       
        $this->end_controls_section();

        $this->start_controls_section(
			'style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_responsive_control(
                'title_font_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .contact-cta-box h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
            
            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .contact-cta-box h3' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'short_title_font_size',
                [
                    'label' => __( 'Short Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .contact-cta-box p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
            
            $this->add_control(
                'short_title_color',
                [
                    'label' => __( 'Short Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .contact-cta-box p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'button_font_size',
                [
                    'label' => __( 'Button Text Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .contact-cta-box .btn' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
            
            $this->add_control(
                'button_background_color',
                [
                    'label' => __( 'Button Background Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .contact-cta-box .btn' => 'background-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'button_background_color_hover',
                [
                    'label' => __( 'Button Background Color Hover', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .contact-cta-box .btn::after, .contact-cta-box .btn::before' => 'background: {{VALUE}}',
                    ],
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        $this-> add_inline_editing_attributes('title','none');
        $this-> add_inline_editing_attributes('short_title','none');

        ?>
            <div class="contact-cta-box">
                <h3 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h3>
                <p <?php echo $this-> get_render_attribute_string('short_title'); ?>><?php echo esc_html( $settings['short_title'] ); ?></p>
                <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
            </div>
        <?php
	}
	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Contact_Box );
?>

