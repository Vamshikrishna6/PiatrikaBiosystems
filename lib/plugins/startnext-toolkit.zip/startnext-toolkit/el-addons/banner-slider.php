<?php
/**
 * Banner Slider Widget
 */

namespace Elementor;
class StartNext_Slider extends Widget_Base {

	public function get_name() {
        return 'StartNext_Slider';
    }

	public function get_title() {
        return __( 'Banner Slider', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-banner';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_Slider_Area',
			[
				'label' => __( 'StartNext Banner Slider Controls', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'title',
            [
                'label' => esc_html__( 'Title', 'tryo-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Secure IT Solutions for a more secure environment', 'startnext-toolkit'),
            ]
        );

        $repeater->add_control(
            'description',
            [
                'label' => esc_html__( 'Description', 'tryo-toolkit' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.', 'startnext-toolkit'),
            ]
        );

        $repeater->add_control(
            'image', 
            [
                'label' => esc_html__( 'Slider Image', 'tryo-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'button_text',
            [
                'label' => __( 'Button Text', 'startnext-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Get Started', 'startnext-toolkit'),
            ]
        );

        $repeater->add_control(
            'button_link',
            [
                'label' => __( 'Button Link', 'startnext-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );
        

        $this->add_control(
            'sliders',
            [
                'label' => esc_html__( 'Add Slider item', 'tryo-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );
        

        $this->end_controls_section();

        $this->start_controls_section(
			'slider_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'show_shape',
			[
				'label' => __( 'Shape Images', 'startnext-toolkit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'startnext-toolkit' ),
				'label_off' => __( 'Hide', 'startnext-toolkit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);


        $this->add_control(
			'bg_color',
			[
				'label' => __( 'Background Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hosting-main-banner, .hosting-boxes-area' => 'background-color: {{VALUE}}',
				],
			]
        );
    
        $this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hero-slider .hosting-main-banner .hosting-banner-content h1' => 'color: {{VALUE}}',
				],
			]
        );

        $this->add_responsive_control(
			'title_size',
			[
				'label' => __( 'Title Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 70,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .hero-slider .hosting-main-banner .hosting-banner-content h1' => 'font-size: {{SIZE}}px;',
				],
			]
		);
        
        $this->add_control(
			'content_color',
			[
				'label' => __( 'Description Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hero-slider .hosting-main-banner .hosting-banner-content p' => 'color: {{VALUE}}',
				],
			]
        );
        
        $this->add_responsive_control(
			'content_size',
			[
				'label' => __( 'Description Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 50,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .hero-slider .hosting-main-banner .hosting-banner-content p' => 'font-size: {{SIZE}}px;',
				],
			]
        );

        $this->add_control(
			'button_color',
			[
				'label' => __( 'Button Background Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hosting-banner-content .btn-primary' => 'background-color: {{VALUE}}',
				],
			]
        );

        $this->add_control(
			'button_hover_color',
			[
				'label' => __( 'Button Hover Background Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .hosting-banner-content .btn::after, .btn::before' => 'background: {{VALUE}}',
				],
			]
        );

        $this->add_responsive_control(
			'button_size',
			[
				'label' => __( 'Button Text Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 20,
						'step' => 1,
					],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .hosting-banner-content .btn' => 'font-size: {{SIZE}}px;',
				],
			]
		);

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();
        
        ?>
        <div class="hero-slider">
            <?php foreach( $settings['sliders'] as $item ): ?>
                <div class="hosting-main-banner">
                    <div class="d-table">
                        <div class="d-table-cell">
                            <div class="container">
                                <div class="row align-items-center">
                                    <div class="col-lg-6 col-md-12">
                                        <div class="hosting-banner-content">
                                            <h1><?php echo esc_html( $item['title'] ); ?></h1>
                                            <p><?php echo esc_html( $item['description'] ); ?></p>

                                            <?php if( $item['button_text'] != '' ): ?>
                                                <a href="<?php echo esc_url( $item['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $item['button_text'] ); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-12">
                                        <div class="slider-image">
                                            <?php if( $item['image']['url'] != '' ):?>
                                                <img src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="<?php echo esc_attr( $item['title'] );?>" class="wow fadeInDown bannerrightimg">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if( $settings['show_shape'] == 'yes' ): ?>
                        <div class="shape1">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape1.png" alt="<?php echo esc_attr( $item['title'] );?>">
                        </div>
                        <div class="shape2 rotateme">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape2.svg" alt="<?php echo esc_attr( $item['title'] );?>">
                        </div>
                        <div class="shape3">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape3.svg" alt="<?php echo esc_attr( $item['title'] );?>">
                        </div>
                        <div class="shape4">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr( $item['title'] );?>">
                        </div>
                        <div class="shape5">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape5.png" alt="<?php echo esc_attr( $item['title'] );?>">
                        </div>
                        <div class="shape6 rotateme">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr( $item['title'] );?>">
                        </div>
                        <div class="shape7">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape4.svg" alt="<?php echo esc_attr( $item['title'] );?>">
                        </div>
                        <div class="shape8 rotateme">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape2.svg" alt="<?php echo esc_attr( $item['title'] );?>">
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Slider );
?>

