<?php
/**
 * More Info Widget
 */

namespace Elementor;
class StartNext_More_Info extends Widget_Base {

	public function get_name() {
        return 'StartNext_More_Info';
    }

	public function get_title() {
        return __( 'More Info', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-info-circle-o';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_More_Info_Area',
			[
				'label' => __( 'More Info Controls', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Choose Style', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( 'Style - 1', 'startnext-toolkit' ),
                        2   => __( 'Style - 2', 'startnext-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('App Development for Connected Devices', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'description',
                [
                    'label' => __( 'Description', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus.', 'startnext-toolkit'),
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Image', 'startnext-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );

            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Explore More', 'startnext-toolkit'),
                ]
            );

            $this->add_control(
                'button_link',
                [
                    'label' => __( 'Button Link', 'startnext-toolkit' ),
                    'type' => Controls_Manager::URL,
                ]
            );
           

        $this->end_controls_section();

        $this->start_controls_section(
			'cta_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .iot-features-content h3' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 10,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .iot-features-content h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
            $this->add_control(
                'description_color',
                [
                    'label' => __( 'Description Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .iot-features-content p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'description_size',
                [
                    'label' => __( 'Description Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 10,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .iot-features-content p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'button_color',
                [
                    'label' => __( 'Button Background Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .iot-features-content .btn-primary'  => 'background-color: {{VALUE}}',
                    ],
                ]
            );
    
            $this->add_control(
                'button_hover_color',
                [
                    'label' => __( 'Button Hover Background Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .iot-features-content .btn::before, .iot-features-content .btn::after' => 'background: {{VALUE}}',
                    ],
                ]
            );
    

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Inline Editing
        $this-> add_inline_editing_attributes('title','none');
        
        
        ?>
        <?php if( $settings['card_style'] == 1 ): ?>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 iot-features-content">
                        <h3 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h3>

                        <p><?php echo $settings['description']; ?></p>

                        <?php if( $settings['button_text'] != '' ): ?>
                            <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-6 iot-features-image">
                        <?php if( $settings['image']['url'] != '' ): ?>
                            <img src="<?php echo esc_url( $settings['image']['url'] );?>" alt="<?php echo esc_attr( $settings['title'] );?>" class="wow fadeInUp" data-wow-delay="0.6s">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style'] == 2 ): ?>
            <div class="container">
                <div class="row align-items-center">

                    <div class="col-lg-6 iot-features-image">
                        <?php if( $settings['image']['url'] != '' ): ?>
                            <img src="<?php echo esc_url( $settings['image']['url'] );?>" alt="<?php echo esc_attr( $settings['title'] );?>" class="wow fadeInUp" data-wow-delay="0.6s">
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-6 iot-features-content">
                        <h3 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h3>

                        <p><?php echo $settings['description']; ?></p>

                        <?php if( $settings['button_text'] != '' ): ?>
                            <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="btn btn-primary"><?php echo esc_html( $settings['button_text'] ); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_More_Info );



?>

