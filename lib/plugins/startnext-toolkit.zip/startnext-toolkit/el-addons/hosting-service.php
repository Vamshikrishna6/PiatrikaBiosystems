<?php
/**
 * Cloud Hosting Service Widget
 */

namespace Elementor;
class StartNext_Hosting_Service extends Widget_Base {

	public function get_name() {
        return 'StartNext_Hosting_Service';
    }

	public function get_title() {
        return __( 'Hosting Service', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-database';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_Hosting_Service_Area',
			[
				'label' => __( 'StartNext Hosting Service Controls', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'image_position',
                [
                    'label' => __( 'Choose Image Position', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'left'      => __( 'Left', 'startnext-toolkit' ),
                        'right'     => __( 'Right', 'startnext-toolkit' ),
                    ],
                    'default' => 'right',
                ]
            );

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Cloud Hosting Services', 'startnext-toolkit'),
                ]
            );

            $this->add_control(
                'content',
                [
                    'label' => __( 'Content', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'startnext-toolkit'),
                ]
            );

            $this->add_control(
                'list_items',
                [
                    'label' => esc_html__('Add List Item', 'startnext-toolkit'),
                    'type' => Controls_Manager::REPEATER,
                    'separator' => 'before',
                    'fields' => [
                        [	
                            'name'	=> 'icon',
                            'label' => __( 'Select Icon', 'startnext-toolkit' ),
                            'type' => Controls_Manager::ICON,
                            'default' => 'fa fa-database',
                        ],

                        [
                            'name'	=> 'list_title',
                            'label' => __( 'List Title', 'startnext-toolkit' ),
                            'type' => Controls_Manager::TEXT,
                            'default' => __('Cloud databases', 'startnext-toolkit'),
                        ],
                    ],
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Choose Image', 'startnext-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );
       
        $this->end_controls_section();

        $this->start_controls_section(
			'hosting_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'title_shape',
                [
                    'label' => __( 'Title Shape', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'startnext-toolkit' ),
                    'label_off' => __( 'Hide', 'startnext-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
            
            $this->add_control(
                'img_shape',
                [
                    'label' => __( 'Image Shape', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'startnext-toolkit' ),
                    'label_off' => __( 'Hide', 'startnext-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .services-area .section-title h2' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 10,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .services-area .section-title h2' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
            
            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Content Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .services-area .section-title p' => 'color: {{VALUE}}',
                    ],
                ]
            );
            
            $this->add_responsive_control(
                'content_size',
                [
                    'label' => __( 'Content Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 10,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .services-area .section-title p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'list_color',
                [
                    'label' => __( 'List Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .services-content .box::before' => 'background: {{VALUE}}',
                        '{{WRAPPER}} .services-content .box i'       => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'section_bg',
                [
                    'label' => __( 'Section Background Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .services-area.bg-f7fafd'  => 'background: {{VALUE}}',
                        '{{WRAPPER}} .services-area'            => 'background: {{VALUE}}',
                    ],
                ]
            );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Inline Editing
        $this-> add_inline_editing_attributes('title','none');
        $this-> add_inline_editing_attributes('content','none');
        
        ?>
        <?php if( $settings['image_position'] == 'right' ): ?>
            <div class="services-area ptb-80 bg-f7fafd">
                <div class="container">
                    <div class="row h-100 justify-content-center align-items-center">
                        <div class="col-lg-6 col-md-12 services-content">
                            <div class="section-title">
                                <h2 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h2>
                                <?php if( $settings['title_shape'] == 'yes' ): ?>
                                    <div class="bar"></div>
                                <?php else: ?>
                                <br>
                                <?php endif; ?>

                                <p <?php echo $this-> get_render_attribute_string('content'); ?>><?php echo esc_html( $settings['content'] ); ?></p>
                            </div>

                            <div class="row">
                                <?php foreach( $settings['list_items'] as $item ): ?>
                                    <div class="col-lg-6 col-md-6">
                                        <div class="box">
                                            <i class="<?php echo esc_attr( $item['icon'] ); ?>"></i> <?php echo esc_html( $item['list_title'] ); ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <?php if( $settings['image']['url'] != '' ): ?>
                            <div class="col-lg-6 col-md-12 services-right-image single-right-image sr-image-bottom">
                                <?php if( $settings['img_shape'] == 'yes' ): ?>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/cercle-shape.png" class="bg-image rotateme" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php endif; ?>
                                <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" class="wow fadeInUp bannerrightimg" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                
                            </div>
                        <?php else: ?>
                            <div class="col-lg-6 col-md-12 services-right-image">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/book-self.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/box.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/chair.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/cloud.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/cup.png" class="wow bounceIn" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/flower-top.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/head-phone.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/monitor.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/mug.png" class="wow rotateIn" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/table.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/tissue.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/water-bottle.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/wifi.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">

                                <?php if( $settings['img_shape'] == 'yes' ): ?>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/cercle-shape.png" class="bg-image rotateme" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php endif; ?>
                                
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-right-image/main-pic.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="main-pic">
                                
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="services-area ptb-80">
                <div class="container">
                    <div class="row h-100 justify-content-center align-items-center">
                        <?php if( $settings['image']['url'] != '' ): ?>
                            <div class="col-lg-6 col-md-12 services-left-image single-left-image">
                                <?php if( $settings['img_shape'] == 'yes' ): ?>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/cercle-shape.png" class="bg-image rotateme" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php endif; ?>
                                <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" class="wow fadeInUp bannerrightimg" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                            </div>
                        <?php else: ?>
                            <div class="col-lg-6 col-md-12 services-left-image">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/big-monitor.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInDown;">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/creative.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/developer.png" class="wow fadeInLeft" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInLeft;">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/flower-top.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>" style="visibility: visible; animation-delay: 0.6s; animation-name: zoomIn;">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/small-monitor.png" class="wow bounceIn" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>" style="visibility: visible; animation-delay: 0.6s; animation-name: bounceIn;">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/small-top.png" class="wow fadeInDown" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInDown;">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/table.png" class="wow zoomIn" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>" style="visibility: visible; animation-delay: 0.6s; animation-name: zoomIn;">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/target.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">

                                <?php if( $settings['img_shape'] == 'yes' ): ?>
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/cercle-shape.png" class="bg-image rotateme" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php endif; ?>

                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/services-left-image/main-pic.png" class="wow fadeInUp" data-wow-delay="0.6s" alt="<?php echo esc_attr( $settings['title'] ); ?>" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
                            </div>
                        <?php endif; ?>
                        <div class="col-lg-6 col-md-12 services-content">
                            <div class="section-title">
                                <h2 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h2>
                                <?php if( $settings['title_shape'] == 'yes' ): ?>
                                    <div class="bar"></div>
                                <?php else: ?>
                                <br>
                                <?php endif; ?>

                                <p <?php echo $this-> get_render_attribute_string('content'); ?>><?php echo esc_html( $settings['content'] ); ?></p>
                            </div>

                            <div class="row">
                                <?php foreach( $settings['list_items'] as $item ): ?>
                                    <div class="col-lg-6 col-md-6">
                                        <div class="box">
                                            <i class="<?php echo esc_attr( $item['icon'] ); ?>"></i> <?php echo esc_html( $item['list_title'] ); ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Hosting_Service );
?>

