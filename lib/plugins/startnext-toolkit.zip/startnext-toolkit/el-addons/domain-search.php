<?php
/**
 * Domain Search Widget
 */

namespace Elementor;
class StartNext_Domain_Search extends Widget_Base {

	public function get_name() {
        return 'Domain_Search';
    }

	public function get_title() {
        return __( 'Domain Search', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-search';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'search_domain',
			[
				'label' => __( 'Domain Search Control', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Find Your Best Domain Name', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Search Button Text', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Search', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'search_placeholder',
                [
                    'label' => __( 'Search Placeholder Text', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Search', 'startnext-toolkit'),
                ]
            );
            
            $this->add_control(
                'domain_items',
                [
                    'type'    => Controls_Manager::REPEATER,
                    'label'   => esc_html__( 'Add Domain Item', 'startnext-toolkit' ),			                 
                    'fields'  => array(					
                        array(
                            'type'    => Controls_Manager::TEXT,
                            'name'    => 'domain_name',
                            'label'   => esc_html__( 'Domain name type', 'startnext-toolkit' ),
                            'default' => __('.com', 'startnext-toolkit'),
                        ),
                        array(
                            'type'    => Controls_Manager::TEXT,
                            'name'    => 'domain_price',
                            'label'   => esc_html__( 'Domain price', 'startnext-toolkit' ),
                            'default' => __('$ 9.88', 'startnext-toolkit'),
                        ),
                    ),	
                ]			
            );

            $this->add_control(
                'domain_available_text',
                [
                    'label' => __( 'Domain Available Text', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                ]
            );

            $this->add_control(
                'domain_unavailable_text',
                [
                    'label' => __( 'Domain Unavailable Text', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .domain-search-content h2' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .domain-search-content h2' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'button_bg_color',
                [
                    'label' => __( 'Button Background Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .domain-search-content form button' => 'background-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'button_hover_bg_color',
                [
                    'label' => __( 'Button Background Hover Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .domain-search-content form button:hover' => 'background-color: {{VALUE}}',
                    ],
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        $unavailable_text   = $settings['domain_unavailable_text'];
        $available_text     = $settings['domain_available_text'];

        $this-> add_inline_editing_attributes('title','none');
        ?>
        <div class="domain-search-area ptb-80 ">
            <div class="container">
                <div class="domain-search-content">
                    <h2><?php echo esc_html( $settings['title'] );?></h2>
                        <form action="" method="GET">
                            <input type="text" class="form-control" name="domain" placeholder="<?php echo esc_attr( $settings['search_placeholder'] ); ?>">
                            <?php if( $settings['button_text'] != ''): ?>
                                <button type="submit"><?php echo esc_attr( $settings['button_text'] ); ?></button>
                            <?php endif; ?>
                        </form>
                        <?php
                        
                        if(isset($_GET['domain'])){
							$AddToEnd = ".";
                            $domain = $_GET['domain'];
							$domainWithDot = implode(array($domain, $AddToEnd));
                        if ( gethostbyname($domainWithDot) != $domainWithDot ) { 
                            if($unavailable_text == ''){ ?>
                                <p class="text-danger"><?php echo wp_kses_post('Sorry, <b style="color:#666666;">', 'startnext-toolkit'); echo esc_html($domain); ?></b> <?php echo wp_kses_post('is unavailable. <br> Please try a different search.', 'startnext-toolkit'); ?></p>
                            <?php }else { ?>
                                <p class="text-danger"><?php echo esc_html($domain); echo wp_kses_post($unavailable_text); ?></p>
                                <?php 
                            }
                        }
                        else {
                            if($available_text == ''){ ?>
                                <p class="text-success"><b style="color:#666666;"><?php echo esc_html($domain); ?></b> <?php echo wp_kses_post('is available!', 'startnext-toolkit'); ?></p>
                            <?php }else { ?>
                                <p class="text-success"><?php echo esc_html($domain); echo wp_kses_post($available_text); ?></p>
                            <?php 
                            }
                        }
                    }
                    ?>
                        <ul class="domain-price">  
                            <?php foreach( $settings['domain_items'] as $item ): ?>
                                <li><?php echo esc_html($item['domain_name']); ?><br><?php echo esc_html($item['domain_price']); ?></li>  
                            <?php endforeach; ?>
                        </ul>
                </div>
            </div>
        </div>
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Domain_Search );
?>

