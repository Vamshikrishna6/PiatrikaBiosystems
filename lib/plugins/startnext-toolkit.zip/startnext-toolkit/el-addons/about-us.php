<?php
/**
 * About Us Widget
 */

namespace Elementor;
class StartNext_About_Us extends Widget_Base {

	public function get_name() {
        return 'StartNext_About_Us';
    }

	public function get_title() {
        return __( 'About Us', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-info-circle-o';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'StartNext_About_Us_Area',
			[
				'label' => __( 'StartNext About Us Controls', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Choose Style', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( 'Style - 1', 'startnext-toolkit' ),
                        2   => __( 'Style - 2', 'startnext-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );

            $this->add_control(
                'top_title',
                [
                    'label' => __( 'Top Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('ABOUT US', 'startnext-toolkit'),
                    'condition' => [
                        'card_style' => '1',
                    ]
                ]
            );

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('We have 35 years of experience in repair services', 'startnext-toolkit'),
                ]
            );
            $this->add_control(
                'content',
                [
                    'label' => __( 'Content', 'startnext-toolkit' ),
                    'type' => Controls_Manager::WYSIWYG,
                ]
            );

            $this->add_control(
                'about_image',
                [
                    'label' => __( 'About Image', 'startnext-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );
            $this->add_control(
                'about_image2',
                [
                    'label' => __( 'About Image 2', 'startnext-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                    'condition' => [
                        'card_style' => '1',
                    ]
                ]
            );
            $this->add_control(
                'about_image3',
                [
                    'label' => __( 'About Image 3', 'startnext-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                    'condition' => [
                        'card_style' => '1',
                    ]
                ]
            );
            $this->add_control(
                'about_image4',
                [
                    'label' => __( 'About Image 4', 'startnext-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                    'condition' => [
                        'card_style' => '1',
                    ]
                ]
            );
            $this->add_control(
                'about_image5',
                [
                    'label' => __( 'About Image 5', 'startnext-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                    'condition' => [
                        'card_style' => '1',
                    ]
                ]
            );
            $this->add_control(
                'lists2',
                [
                    'type'    => Controls_Manager::REPEATER,
                    'label'   => esc_html__( 'Add List Text', 'startnext-toolkit' ),			                 
                    'fields'  => array(		
                        array(
                            'type'    => Controls_Manager::TEXT,
                            'name'    => 'list_text',
                            'label'   => esc_html__( 'Title', 'startnext-toolkit' ),
                            'default' => __(' Experienced Professionals', 'startnext-toolkit'),
                        ),	
                        array(
                            'type'    => Controls_Manager::TEXTAREA,
                            'name'    => 'list_desc',
                            'label'   => esc_html__( 'Description', 'startnext-toolkit' ),
                            'default' => __('Lorem ipsum dolor sit amet, con se ctetur adipiscing elit. In sagittis eg esta ante, sed viverra nunc tinci dunt nec elei fend et tiram.', 'startnext-toolkit'),
                        ),
                    ),	
                    'condition' => [
                        'card_style' => '2',
                    ]
                ]			
            );
            $this->add_control(
                'lists',
                [
                    'type'    => Controls_Manager::REPEATER,
                    'label'   => esc_html__( 'Add List Text', 'startnext-toolkit' ),			                 
                    'fields'  => array(		
                        array(
                            'type'    => Controls_Manager::TEXT,
                            'name'    => 'list_text',
                            'label'   => esc_html__( 'Title', 'startnext-toolkit' ),
                            'default' => __(' Experienced Professionals', 'startnext-toolkit'),
                        ),
                    ),	
                    'condition' => [
                        'card_style' => '1',
                    ]
                ]			
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'about_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
            $this->add_control(
                'top_title_color',
                [
                    'label' => __( 'Top Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .repair-about-content .sub-title' => 'color: {{VALUE}}',
                    ],
                    'condition' => [
                        'card_style' => '1',
                    ]
                ]
            );

            $this->add_responsive_control(
                'top_title_size',
                [
                    'label' => __( 'Top Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 10,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .repair-about-content .sub-title' => 'font-size: {{SIZE}}px;',
                    ],
                    'condition' => [
                        'card_style' => '1',
                    ]
                ]
            );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'startnext-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .repair-about-content h2, .section-title h2' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 10,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .repair-about-content h2, .section-title h2' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
        
        

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Inline Editing
        $this-> add_inline_editing_attributes('title','none');
        
        ?>
            <?php if( $settings['card_style'] == 1 ): ?>
                <div class="repair-about-area ptb-80">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="repair-about-content">
                                    <span class="sub-title"><?php echo esc_html( $settings['top_title'] ); ?></span>
                                    <h2 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo esc_html( $settings['title'] ); ?></h2>
                                    <?php echo $settings['content']; ?>
                                    <ul>
                                        <?php foreach( $settings['lists'] as $item ): ?>
                                            <li><span><i data-feather="check"></i> <?php echo esc_html($item['list_text']); ?></span></li>
                                        <?php endforeach; ?>

                                    </ul>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="repair-about-image">
                                    <?php if( $settings['about_image']['url'] != '' ): ?>
                                        <img src="<?php echo esc_url($settings['about_image']['url']); ?>" class="wow fadeInDown" alt="<?php echo esc_html( $settings['title'] ); ?>">
                                    <?php endif; ?>

                                    <?php if( $settings['about_image2']['url'] != '' ): ?>
                                        <img src="<?php echo esc_url($settings['about_image2']['url']); ?>" class="wow zoomIn" alt="<?php echo esc_html( $settings['title'] ); ?>">
                                    <?php endif; ?>

                                    <?php if( $settings['about_image3']['url'] != '' ): ?>
                                        <img src="<?php echo esc_url($settings['about_image3']['url']); ?>" class="wow fadeInUp" alt="<?php echo esc_html( $settings['title'] ); ?>">
                                    <?php endif; ?>

                                    <?php if( $settings['about_image4']['url'] != '' ): ?>
                                        <img src="<?php echo esc_url($settings['about_image4']['url']); ?>" alt="<?php echo esc_html( $settings['title'] ); ?>">
                                    <?php endif; ?>

                                    <?php if( $settings['about_image5']['url'] != '' ): ?>
                                        <img src="<?php echo esc_url($settings['about_image5']['url']); ?>" alt="<?php echo esc_html( $settings['title'] ); ?>">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php elseif( $settings['card_style'] == 2 ): ?>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-12">
                            <div class="about-image">
                                <?php if( $settings['about_image']['url'] != '' ): ?>
                                    <img src="<?php echo esc_url( $settings['about_image']['url'] );?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div class="about-content">
                                <div class="section-title">
                                    <h2><?php echo esc_html( $settings['title'] ); ?></h2>
                                    <div class="bar"></div>

                                    <?php echo $settings['content']; ?>
                            </div>
                        </div>
                    </div>

                    <div class="about-inner-area">
                        <div class="row">
                            <?php foreach( $settings['lists2'] as $list ): ?>
                                <div class="col-lg-4 col-md-6">
                                    <div class="about-text">
                                        <h3><?php echo esc_html( $list['list_text'] ); ?></h3>
                                        <p><?php echo esc_html( $list['list_desc'] ); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php
	}

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_About_Us );



?>

