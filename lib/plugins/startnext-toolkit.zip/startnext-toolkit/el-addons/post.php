<?php
/**
 * Blog Post Widget
 */

namespace Elementor;
class StartNext_Blog_Post extends Widget_Base {

	public function get_name() {
        return 'StartNextBlogPost';
    }

	public function get_title() {
        return __( 'Blog Post', 'startnext-toolkit' );
    }

	public function get_icon() {
        return 'eicon-posts-grid';
    }

	public function get_categories() {
        return [ 'startnext-elements' ];
    }

	protected function _register_controls() {

        $this->start_controls_section(
			'blog_section',
			[
				'label' => __( 'Blog Post', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
            $this->add_control(
                'columns',
                [
                    'label' => __( 'Choose Columns', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        2   => __( '2', 'startnext-toolkit' ),
                        3   => __( '3', 'startnext-toolkit' ),
                        4   => __( '4', 'startnext-toolkit' ),
                    ],
                    'default' => 3,
                ]
            );

            $this->add_control(
                'order',
                [
                    'label' => __( 'Post Order By', 'startnext-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'DESC'      => __( 'DESC', 'startnext-toolkit' ),
                        'ASC'       => __( 'ASC', 'startnext-toolkit' ),
                    ],
                    'default' => 'DESC',
                ]
            );

            $this->add_control(
                'count',
                [
                    'label' => __( 'Post Per Page', 'startnext-toolkit' ),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 3,
                ]
            );
            
            $this->add_control(
                'read_more_text',
                [
                    'label' => __( 'Post Read More Text', 'startnext-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Read More', 'startnext-toolkit'),
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'post_style',
			[
				'label' => __( 'Style', 'startnext-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'main_color',
			[
				'label' => __( 'Main Color Color', 'startnext-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-blog-post .blog-post-content h3 a, .single-blog-post .blog-post-content ul li a, .single-blog-post .blog-post-content .read-more-btn:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .single-blog-post .blog-image .date' => 'background: {{VALUE}}',
				],
			]
        );

        $this->add_responsive_control(
			'title_size',
			[
				'label' => __( 'Title Font Size', 'startnext-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 40,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .single-blog-post .blog-post-content h3' => 'font-size: {{SIZE}}px;',
				],
			]
		);

        $this->end_controls_section();

    }

	protected function render() { 
        $settings = $this->get_settings_for_display();

        $args = array(
            'order' => $settings['order'], 
            'posts_per_page' => $settings['count'], 
            'ignore_sticky_posts' => 1, 
            'meta_key' => '_thumbnail_id'
        );
        $post_array = new \WP_Query( $args ); 

        $columns = $settings['columns'];
        if ($columns == 2) {
            $column = 'col-lg-6 col-md-6';
        }elseif ($columns == 3) {
            $column = 'col-lg-4 col-md-6';
        }elseif ($columns == 4) {
            $column = 'col-lg-3 col-md-6';
        }

        ?>
        <div class="container">
            <div class="row">
                <?php while($post_array->have_posts()): $post_array->the_post(); ?>
                    <div class="<?php echo esc_html($column); ?>">
                        <div class="single-blog-post ">
                            <div class="blog-image">
                                <a href="<?php the_permalink(); ?>">
                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url()) ?>" alt="<?php the_title(); ?>">
                                </a>
                                <div class="date">
                                    <i data-feather="calendar"></i><?php echo esc_html__(get_the_date('F d, Y')); ?>
                                </div>
                            </div>

                            <div class="blog-post-content custom-padding">
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

                                <ul>
                                    <li>
                                        <i class="fa fa-user"></i>
                                        <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) ); ?>"><?php echo esc_html__(get_the_author()); ?></a>
                                    </li>
                                </ul>

                                <p><?php the_excerpt(); ?></p>
                                
                                <div class="mt-2">
                                    <?php if( $settings['read_more_text'] != '' ): ?>
                                        <a href="<?php the_permalink(); ?>" class="read-more-btn"><?php echo esc_html( $settings['read_more_text'] ); ?> <i data-feather="arrow-right"></i> </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
            </div>
        </div>

    <?php 
    } 

	protected function _content_template() {}

}

Plugin::instance()->widgets_manager->register_widget_type( new StartNext_Blog_Post );
?>

